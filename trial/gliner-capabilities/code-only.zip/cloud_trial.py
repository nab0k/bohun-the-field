"""Reviewed code-only cloud executor. No work without explicit modes/gates."""
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import zipfile

BASE=Path(__file__).resolve().parent
TRIAL='exp009-gliner-capabilities-v1-20261027'
LABEL='exp009-gliner-capabilities-live-20261027'
REPO='nab0k/bohun-the-field'
FILES={'cloud_trial.py','runtime/run.py','runtime/prepare.py','linux-lock.json'}
RESULT_CAP=4*1024**2


def need(condition,code):
    if not condition:raise ValueError(code)


def sha(raw):return hashlib.sha256(raw).hexdigest()


def strict_json(raw,limit=RESULT_CAP):
    need(isinstance(raw,bytes) and len(raw)<=limit,'JSON_CAP')
    def unique(pairs):
        result={}
        for key,value in pairs:
            need(key not in result,'DUPLICATE_KEY');result[key]=value
        return result
    return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda v:need(False,'NONFINITE_JSON'))


def encode(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def schema_bytes(value):
    return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()


def put(path,raw):
    path=Path(path);path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    with path.open('xb') as out:out.write(raw)
    path.chmod(0o600)


def unpack(raw,manifest,directory):
    need(set(manifest['files'])==FILES and len(raw)<=2*1024**2,'BUNDLE_ALLOWLIST')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos=archive.infolist()
        need(len(infos)==len(FILES) and {i.filename for i in infos}==FILES,'BUNDLE_NAMES')
        need(sum(i.file_size for i in infos)<=2*1024**2,'BUNDLE_EXPANDED_CAP')
        for info in infos:
            need((info.external_attr>>16)&0o170000!=0o120000,'BUNDLE_SYMLINK')
            data=archive.read(info)
            need(sha(data)==manifest['files'][info.filename],'BUNDLE_HASH')
            put(Path(directory)/info.filename,data)


def decode_packet(encoded,plan,packet_manifest):
    need(isinstance(encoded,bytes) and len(encoded)<=48*1024,'PACKET_B64_CAP')
    need(sha(encoded)==plan['packet_sha256'],'PACKET_B64_HASH')
    with gzip.GzipFile(fileobj=io.BytesIO(base64.b64decode(encoded,validate=True))) as inp:
        raw=inp.read(256*1024+1)
    need(len(raw)<=256*1024 and sha(raw)==plan['packet_json_sha256'],'PACKET_JSON_HASH')
    packet=strict_json(raw,256*1024)
    need(set(packet)=={'documents','schema'},'PACKET_FIELDS')
    docs=packet['documents']; config=packet['schema']
    need(isinstance(docs,list) and len(docs)==12,'DOCUMENT_COUNT')
    need({d['id'] for d in docs}=={f'd{n:02}' for n in range(1,13)},'DOCUMENT_IDS')
    for doc in docs:
        need(set(doc)=={'id','title','text','url','published'},'DOCUMENT_FIELDS')
        need(isinstance(doc['text'],str) and 0<len(doc['text'].encode())<=128*1024,'DOCUMENT_TEXT')
        need(isinstance(doc['title'],str) and isinstance(doc['url'],str),'DOCUMENT_TYPES')
        need(sha(doc['text'].encode())==packet_manifest['document_hashes'].get(doc['id']),'DOCUMENT_PIN')
    need(set(config)=={'entities','relations','classification','settings'},'SCHEMA_FIELDS')
    need(sha(encode(config))==packet_manifest['schema_sha256'],'SCHEMA_PIN')
    # The old cloud collector retains a harmless empty groups.json for compatibility;
    # no event pairing, principal-event selection, or gold is sent to the model.
    return {'documents':docs,'groups':[],'schemas':config}


def validate_gate(event,env,plan,history,now):
    required={'enabled','trial','repository','pr','head_sha','branch','label','expires_epoch',
              'bundle_sha256','manifest_sha256','certificate_sha256','packet_sha256','packet_json_sha256','packet_manifest_sha256'}
    need(set(plan)==required,'PLAN_FIELDS')
    need(plan['enabled'] is True and plan['trial']==TRIAL and plan['repository']==REPO and plan['label']==LABEL,'PLAN_IDENTITY')
    need(type(plan['expires_epoch']) in (int,float) and now<plan['expires_epoch']<=now+72*3600,'PLAN_EXPIRY')
    need(env.get('GITHUB_REPOSITORY')==REPO and env.get('GITHUB_ACTOR')=='nab0k','OWNER_REPO_GATE')
    need(env.get('GITHUB_EVENT_NAME')=='pull_request' and env.get('GITHUB_RUN_ATTEMPT')=='1','EVENT_ATTEMPT_GATE')
    need(event.get('action')=='labeled' and event.get('label',{}).get('name')==LABEL,'LABEL_GATE')
    pr=event['pull_request']
    need(type(plan['pr']) is int and plan['pr']==event['number'],'PR_NUMBER_GATE')
    need(pr['head']['repo']['full_name']==REPO and pr['base']['repo']['full_name']==REPO,'NO_FORK')
    need(pr['head']['sha']==plan['head_sha'] and re.fullmatch('[a-f0-9]{40}',plan['head_sha']),'HEAD_GATE')
    need(pr['head']['ref']==plan['branch'] and plan['branch'].startswith('codex/'),'BRANCH_GATE')
    need(all(isinstance(plan[k],str) and re.fullmatch('[a-f0-9]{64}',plan[k]) for k in required if k.endswith('sha256')),'PLAN_HASHES')
    runs=history.get('workflow_runs')
    need(isinstance(runs,list) and history.get('total_count')==len(runs) and len(runs)<=100,'HISTORY_UNKNOWN')
    for run in runs:
        if TRIAL in run.get('display_title',''):
            need(str(run['id'])==env.get('GITHUB_RUN_ID') and run.get('run_attempt',1)==1,'TRIAL_ALREADY_ATTEMPTED')
    return True


def openssl(args,data=None):
    done=subprocess.run(['openssl',*args],input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
    need(done.returncode==0,'CRYPTO_FAILED')
    return done.stdout


def keys(directory,testing=False):
    directory=Path(directory);directory.mkdir(mode=0o700,parents=True,exist_ok=True)
    key=directory/'owner-key.pem';cert=directory/'owner-cert.pem'
    need(not key.exists() and not cert.exists(),'KEY_NO_OVERWRITE')
    openssl(['req','-x509','-newkey','rsa:3072','-nodes','-days','1' if testing else '7',
             '-subj','/CN=BOHUN-EVENT-CHECK-TEST' if testing else '/CN=BOHUN-EVENT-CHECK-OWNER',
             '-keyout',str(key),'-out',str(cert)])
    key.chmod(0o600);cert.chmod(0o600)
    return key,cert


def seal(raw,cert):
    need(len(raw)<=RESULT_CAP and Path(cert).stat().st_size<=8192,'SEAL_CAP')
    need(b'PRIVATE KEY' not in Path(cert).read_bytes(),'PUBLIC_CERT_REQUIRED')
    return openssl(['cms','-encrypt','-binary','-aes-256-gcm','-outform','DER',str(cert)],raw)


def decrypt(raw,key,cert):
    need(len(raw)<=RESULT_CAP+16384 and Path(key).stat().st_mode&0o077==0,'DECRYPT_CAP_MODE')
    return openssl(['cms','-decrypt','-binary','-inform','DER','-inkey',str(key),'-recip',str(cert)],raw)


def ciphertext_log(raw):
    need(len(raw)<=RESULT_CAP+16384,'CIPHER_CAP')
    data=base64.b64encode(raw).decode();chunks=[data[n:n+2048] for n in range(0,len(data),2048)]
    begin={'trial':TRIAL,'sha256':sha(raw),'bytes':len(raw),'parts':len(chunks)}
    return '\n'.join(['BOHUN_EC_BEGIN '+encode(begin).decode()]+[f'BOHUN_EC_PART {n} {chunk}' for n,chunk in enumerate(chunks)]+['BOHUN_EC_END '+sha(raw)])


def ciphertext_from_log(text):
    # GitHub may prefix timestamp/step columns; anchors must still be exact once found.
    need(len(text.encode())<=16*1024**2,'LOG_CAP')
    lines=[line[line.index('BOHUN_EC_'):] for line in text.splitlines() if 'BOHUN_EC_' in line]
    need(lines and lines[0].startswith('BOHUN_EC_BEGIN ') and lines[-1].startswith('BOHUN_EC_END '),'LOG_MARKERS')
    begin=strict_json(lines[0].split(' ',1)[1].encode(),4096)
    need(begin['trial']==TRIAL and type(begin['parts']) is int and 0<begin['parts']<=3000,'LOG_HEADER')
    need(len(lines)==begin['parts']+2,'LOG_PART_COUNT')
    parts=[]
    for n,line in enumerate(lines[1:-1]):
        match=re.fullmatch(r'BOHUN_EC_PART ([0-9]+) ([A-Za-z0-9+/=]{1,2048})',line)
        need(match is not None and int(match[1])==n,'LOG_PART_ORDER');parts.append(match[2])
    raw=base64.b64decode(''.join(parts),validate=True)
    need(len(raw)<=RESULT_CAP+16384 and len(raw)==begin['bytes'] and sha(raw)==begin['sha256'],'LOG_DIGEST')
    need(lines[-1]=='BOHUN_EC_END '+sha(raw),'LOG_END')
    return raw


def safe_env(home):
    return {'PATH':'/usr/bin:/bin','HOME':str(home),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1',
            'PIP_CONFIG_FILE':'/dev/null','PIP_DISABLE_PIP_VERSION_CHECK':'1','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1'}


def native_integrity(runtime):
    runtime=Path(runtime)
    wheel=next((runtime/'wheels').glob('gliner2-2.1.0-*.whl'))
    site=runtime/'venv/lib/python3.13/site-packages';pins={}
    with zipfile.ZipFile(wheel) as archive:
        for name in archive.namelist():
            if name.startswith('gliner2/') and name.endswith('.py'):
                actual=site/name
                need(actual.is_file() and sha(actual.read_bytes())==sha(archive.read(name)),'NATIVE_CODE_CHANGED')
                pins[name]=sha(actual.read_bytes())
    need(len(pins)==91,'NATIVE_SOURCE_COUNT')
    return pins


def lock_valid(lock):
    need(lock.get('platform')=='ubuntu-24.04-x86_64' and lock.get('python')=='3.13','LOCK_TARGET')
    packages=lock['packages'];models=lock['model']
    need(0<len(packages)<=80 and len({p['name'].lower() for p in packages})==len(packages),'LOCK_PACKAGES')
    need(any(p['name']=='torch' and p['version']=='2.14.1+cpu' for p in packages),'CPU_TORCH_REQUIRED')
    need(not any(any(s in p['name'].lower() for s in ['cuda','nvidia','triton']) for p in packages),'NON_CPU_LOCK')
    need({m['path'] for m in models}=={'config.json','encoder_config/config.json','tokenizer_config.json','tokenizer.json','model.safetensors'},'MODEL_ALLOWLIST')
    need(lock['model_revision']=='cf5593a5d45e3bbf204b9df621b13b1c0cf25ee3','MODEL_REVISION')
    hosts={'files.pythonhosted.org','download.pytorch.org','download-r2.pytorch.org','huggingface.co'}
    for item in packages+models:
        need(type(item['bytes']) is int and item['bytes']>0 and re.fullmatch('[a-f0-9]{64}',item['sha256']),'LOCK_PIN')
        parsed=urllib.parse.urlparse(item['url'])
        need(parsed.scheme=='https' and parsed.hostname in hosts and not parsed.username and not parsed.password,'LOCK_URL')
        name=item.get('filename',item.get('path'))
        need('..' not in Path(name).parts and not Path(name).is_absolute(),'LOCK_PATH')
        if item in packages:need(name.endswith('.whl') and '/' not in name,'WHEEL_ONLY')
    size=sum(v['bytes'] for v in packages+models)
    need(size==lock['payload_bytes'] and size<=2*1024**3,'LOCK_DOWNLOAD_CAP')
    return True


def acquire(lock,runtime,fetch=urllib.request.urlopen,clock=time.monotonic):
    lock_valid(lock);runtime=Path(runtime);began=clock();total=0
    ledger={'downloads':[],'downloaded_bytes':0}
    for item in lock['packages']+lock['model']:
        need(clock()-began<1200,'ACQUISITION_TIMEOUT')
        relative='wheels/'+item['filename'] if 'filename' in item else 'model/'+item['path']
        dest=runtime/relative;dest.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        digest=hashlib.sha256();size=0
        request=urllib.request.Request(item['url'],headers={'User-Agent':'BOHUN-frozen-trial/1'})
        with fetch(request,timeout=min(45,1200-(clock()-began))) as response,dest.open('xb') as out:
            while chunk:=response.read(1024**2):
                size+=len(chunk);total+=len(chunk)
                need(size<=item['bytes'] and total<=2*1024**3,'DOWNLOAD_SIZE_CAP')
                need(clock()-began<1200,'ACQUISITION_TIMEOUT')
                out.write(chunk);digest.update(chunk)
        dest.chmod(0o600)
        need(size==item['bytes'] and digest.hexdigest()==item['sha256'],'DOWNLOAD_PIN')
        ledger['downloads'].append({'path':relative,'bytes':size,'sha256':digest.hexdigest()})
        ledger['downloaded_bytes']=total
        (runtime/'acquisition.json').write_bytes(encode(ledger))
    env=safe_env(runtime/'home')
    (runtime/'home').mkdir(mode=0o700,exist_ok=True)
    left=lambda:1200-(clock()-began)
    need(left()>0,'ACQUISITION_TIMEOUT')
    expanded=0
    for item in lock['packages']:
        with zipfile.ZipFile(runtime/'wheels'/item['filename']) as archive:
            expanded+=sum(i.file_size for i in archive.infolist())
    # Include existing payload + fully expanded wheel contents + conservative venv/log reserve.
    need(total+expanded+256*1024**2<=4*1024**3,'PROJECTED_DISK_CAP')
    with (runtime/'install.log').open('w') as log:
        subprocess.run([sys.executable,'-m','venv',str(runtime/'venv')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=left())
        req='\n'.join(f'{p["name"]}=={p["version"]} --hash=sha256:{p["sha256"]}' for p in lock['packages'])+'\n'
        put(runtime/'requirements.lock',req.encode())
        need(left()>0,'ACQUISITION_TIMEOUT')
        subprocess.run([str(runtime/'venv/bin/python'),'-m','pip','install','--no-index','--no-deps','--no-compile',
                       '--find-links',str(runtime/'wheels'),'--require-hashes','-r',str(runtime/'requirements.lock')],
                       env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=left())
    need(sum(f.stat().st_size for f in runtime.rglob('*') if f.is_file())<=4*1024**3,'TRIAL_DISK_CAP')
    put(runtime/'native-before.json',encode(native_integrity(runtime)))
    return ledger


def collect(runtime,status,provenance=None):
    files={}
    allowed=['inputs/documents.json','inputs/groups.json','schemas.json','prepared.json','acquisition.json',
             'resource-preflight.json','started.json','progress.json','worker-result.json','result.json','worker.log','install.log',
             'native-before.json','native-after.json','supervisor.log']
    allowed += [str(p.relative_to(runtime)) for p in sorted((runtime/'results').glob('*.json'))]
    for name in allowed:
        p=runtime/name
        if p.exists():
            need(p.stat().st_size<=2*1024**2,'RESULT_FILE_CAP')
            files[name]=base64.b64encode(p.read_bytes()).decode()
    receipt={'trial':TRIAL,'status':status,'publication_status':'HOLD','public_release':False,
             'files':files,'file_hashes':{n:sha(base64.b64decode(v)) for n,v in files.items()},
             'evaluation':'NOT_RUN_LOCAL_ONLY','API_expense_USD':0,'provenance':provenance or {}}
    raw=encode(receipt);need(len(raw)<=RESULT_CAP,'RECEIPT_CAP');return raw


def terminate_tree(pid):
    """Linux /proc PID/PPID only; no command-line or environment inspection."""
    children={}
    for entry in Path('/proc').iterdir():
        if entry.name.isdigit():
            try:
                data=(entry/'status').read_text()
                parent=int(re.search(r'^PPid:\s+(\d+)',data,re.M)[1])
                children.setdefault(parent,[]).append(int(entry.name))
            except (FileNotFoundError,ProcessLookupError,PermissionError,TypeError):pass
    def visit(parent):
        out=[]
        for child in children.get(parent,[]):out.extend(visit(child));out.append(child)
        return out
    for target in visit(pid)+[pid]:
        try:os.kill(target,signal.SIGKILL)
        except ProcessLookupError:pass


def preflight(base):
    """Future live gate; reads no data-secret or model credential."""
    base=Path(base)
    need(sys.platform=='linux','CLOUD_LINUX_ONLY')
    event=strict_json(Path(os.environ['GITHUB_EVENT_PATH']).read_bytes(),512*1024)
    body=event['pull_request'].get('body','');start='BOHUN_GLINER_CAP_APPROVAL_BEGIN\n';end='\nBOHUN_GLINER_CAP_APPROVAL_END'
    need(isinstance(body,str) and body.count(start)==body.count(end)==1,'APPROVAL_BLOCK')
    plan=strict_json(body.split(start)[1].split(end)[0].encode(),16384)
    # History read comes before secret/data exposure. No retry on HTTP/unknown.
    url='https://api.github.com/repos/'+REPO+'/actions/workflows/exp009-gliner-capabilities.yml/runs?event=pull_request&per_page=100&head_sha='+plan['head_sha']
    req=urllib.request.Request(url,headers={'Authorization':'Bearer '+os.environ['GITHUB_TOKEN'],'Accept':'application/vnd.github+json'})
    with urllib.request.urlopen(req,timeout=30) as response:history=strict_json(response.read(2*1024**2+1),2*1024**2)
    validate_gate(event,os.environ,plan,history,time.time())
    manifest_raw=(base/'bundle-manifest.json').read_bytes();bundle=(base/'code-only.zip').read_bytes()
    need(sha(manifest_raw)==plan['manifest_sha256'] and sha(bundle)==plan['bundle_sha256'],'DEPLOYMENT_PIN')
    need(sha((base/'owner-cert.pem').read_bytes())==plan['certificate_sha256'],'CERTIFICATE_PIN')
    need(sha((base/'packet-manifest.json').read_bytes())==plan['packet_manifest_sha256'],'PACKET_MANIFEST_PIN')
    runtime_root=Path(os.environ['RUNNER_TEMP'])/'bohun-gliner-capabilities'
    need(not runtime_root.exists(),'RUNTIME_NO_OVERWRITE');runtime_root.mkdir(mode=0o700)
    unpack(bundle,strict_json(manifest_raw),runtime_root)
    for name in ['owner-cert.pem','packet-manifest.json']:put(runtime_root/name,(base/name).read_bytes())
    put(runtime_root/'gate.json',encode({'plan':plan,'run_id':os.environ['GITHUB_RUN_ID'],'validated_epoch':time.time()}))
    return runtime_root


def cloud(base,allow_live=False):
    need(allow_live and sys.platform=='linux','EXPLICIT_CLOUD_ONLY')
    base=Path(base);gate=strict_json((base/'gate.json').read_bytes(),16384);plan=gate['plan']
    need(gate['run_id']==os.environ.get('GITHUB_RUN_ID') and time.time()<plan['expires_epoch'],'CLOUD_GATE_CONTEXT')
    need(not (base/'attempt-started.json').exists(),'NO_RETRY')
    cert=base/'owner-cert.pem';need(sha(cert.read_bytes())==plan['certificate_sha256'],'CERTIFICATE_PIN')
    put(base/'attempt-started.json',encode({'trial':TRIAL,'run_id':gate['run_id'],'epoch':time.time()}))
    runtime=base/'runtime';status={'state':'PARTIAL','phase':'packet'}
    try:
        encoded=os.environ.pop('EXP009_GLINER_CAP_PACKET_B64').encode('ascii')
        pm=strict_json((base/'packet-manifest.json').read_bytes(),16384)
        need(sha(encode(pm))==plan['packet_manifest_sha256'],'PACKET_MANIFEST_CANONICAL')
        packet=decode_packet(encoded,plan,pm)
        status['phase']='acquisition'
        lock=strict_json((base/'linux-lock.json').read_bytes(),512*1024)
        acquire(lock,runtime)
        put(runtime/'lock.json',encode(lock))
        put(runtime/'inputs/documents.json',encode(packet['documents']))
        put(runtime/'inputs/groups.json',encode(packet['groups']))
        put(runtime/'schemas.json',schema_bytes(packet['schemas']))
        hashes={n:sha((runtime/n).read_bytes()) for n in ['inputs/documents.json','inputs/groups.json','schemas.json']}
        put(runtime/'prepared.json',encode({'files':hashes,'status':'CLOUD_FROZEN_NO_EVALUATION'}))
        status['phase']='inference'
        env=safe_env(runtime/'home')
        # runtime/run.py supervises the actual model subprocess, deadline and RSS.
        with (runtime/'supervisor.log').open('w') as log:
            done=subprocess.Popen([str(runtime/'venv/bin/python'),'-B',str(runtime/'run.py')],env=env,
                                  stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            try:done.wait(timeout=1230)
            except subprocess.TimeoutExpired:
                terminate_tree(done.pid);done.wait();raise
        status.update({'state':'RETURNED_UNEVALUATED' if done.returncode==0 and (runtime/'worker-result.json').exists() else 'PARTIAL',
                       'returncode':done.returncode,'phase':'finished'})
        after=native_integrity(runtime)
        need(encode(after)==(runtime/'native-before.json').read_bytes(),'NATIVE_AFTER_CHANGED')
        put(runtime/'native-after.json',encode(after))
    except BaseException as exc:
        status.update({'state':'PARTIAL','error_type':type(exc).__name__,'error_detail':str(exc)[:2000]})
    provenance={'run_id':gate['run_id'],'head_sha':plan['head_sha'],
                'bundle_sha256':plan['bundle_sha256'],'packet_json_sha256':plan['packet_json_sha256']}
    try:
        raw=collect(runtime,status,provenance)
    except BaseException as exc:
        raw=encode({'trial':TRIAL,'status':{'state':'PARTIAL','phase':'receipt','error_type':type(exc).__name__},
                    'publication_status':'HOLD','public_release':False,'files':{},'file_hashes':{},'evaluation':'NOT_RUN_LOCAL_ONLY',
                    'API_expense_USD':0,'provenance':provenance})
    cipher=seal(raw,cert);put(base/'receipt.cms',cipher)
    print(ciphertext_log(cipher),flush=True)
    return status


if __name__=='__main__':
    os.umask(0o077)
    # These modes are candidates only; live use needs owner GitHub/live authorization.
    if sys.argv[1:]==['preflight']:
        preflight(BASE)
    elif sys.argv[1:]==['cloud','--allow-live']:
        cloud(BASE,True)
    else:raise SystemExit('explicit preflight or separately authorized cloud --allow-live required')
