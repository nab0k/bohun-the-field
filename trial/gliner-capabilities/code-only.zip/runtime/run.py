"""Native GLiNER capability diagnostic. No event identity or generation."""
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def save(name, value):
    path = ROOT/name
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    path.chmod(0o600)


def verify():
    prepared = json.loads((ROOT/'prepared.json').read_bytes())
    for name, expected in prepared['files'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest() != expected:
            raise ValueError('INPUT_PIN_CHANGED')
    lock = json.loads((ROOT/'lock.json').read_bytes())
    for item in lock['model']:
        with (ROOT/'model'/item['path']).open('rb') as inp:
            actual = hashlib.file_digest(inp, 'sha256').hexdigest()
        if actual != item['sha256']: raise ValueError('MODEL_PIN_CHANGED')


def network_off(*args, **kwargs):
    raise RuntimeError('INFERENCE_NETWORK_FORBIDDEN')


def verify_coverage(text, observed):
    if len(observed) != 1: raise RuntimeError('CHUNK_OBSERVATION_UNKNOWN')
    covered = set()
    for window in observed[0]['chunks']:
        a, b = window['start'], window['end']
        if not (type(a) is int and type(b) is int and 0 <= a < b <= len(text)):
            raise RuntimeError('INVALID_CHUNK_OFFSETS')
        covered.update(range(a,b))
    if any(i not in covered for i, c in enumerate(text) if not c.isspace()):
        raise RuntimeError('DOCUMENT_COVERAGE_GAP')


def worker():
    socket.socket.connect = network_off
    socket.create_connection = network_off
    socket.getaddrinfo = network_off
    import torch
    from gliner2 import AutoExtractor
    torch.set_num_threads(2)
    torch.set_num_interop_threads(2)
    config = json.loads((ROOT/'schemas.json').read_bytes())
    settings = config['settings']
    documents = json.loads((ROOT/'inputs/documents.json').read_bytes())
    calls, forwards, windows = [], [], []
    result = {'documents': {}, 'controls': {}, 'completed': False}
    def flush():
        save('progress.json', {'calls': calls, 'forwards': forwards, 'windows': windows})
        save('results/predictions.json', result)
    def observe(frame, event, arg):
        if event == 'return' and frame.f_code.co_name == 'split_text_into_chunks' and isinstance(arg, list):
            windows.append({'call': calls[-1]['stage'] if calls else 'loading',
                            'chunks': [{'start': c.start_char, 'end': c.end_char} for c in arg]})
    sys.setprofile(observe)
    def timeout(*args): raise TimeoutError('CALL_TIMEOUT')
    signal.signal(signal.SIGALRM, timeout)
    signal.alarm(120)
    model = AutoExtractor.from_pretrained(str(ROOT/'model'), local_files_only=True).to('cpu').eval()
    signal.alarm(0)
    def count(module, args, kwargs):
        if len(forwards) >= settings['forwards_max']: raise RuntimeError('FORWARD_CAP')
        tensor = kwargs.get('input_ids', args[0] if args else None)
        shape = list(tensor.shape) if tensor is not None else None
        if shape and shape[-1] > model.config.max_len: raise ValueError('CONTEXT_OVERFLOW')
        forwards.append({'number': len(forwards)+1, 'shape': shape,
                         'stage': calls[-1]['stage'] if calls else 'load'})
    model.encoder.register_forward_pre_hook(count, with_kwargs=True)
    def call(stage, fn):
        if len(calls) >= settings['calls_max']: raise RuntimeError('CALL_CAP')
        record = {'stage': stage, 'state': 'STARTED'}
        calls.append(record); flush(); began = time.monotonic(); signal.alarm(120)
        try:
            with torch.inference_mode(): value = fn()
            record['state'] = 'RETURNED'
            return value
        except BaseException as exc:
            record.update(state='ERROR', error_type=type(exc).__name__)
            raise
        finally:
            signal.alarm(0); record['elapsed_s'] = time.monotonic()-began; flush()
    # Sanity controls, not evidence of general accuracy; continue even on semantic
    # mismatch so that all independently scored real-news tasks can be measured.
    result['controls']['entities'] = call('control:entities', lambda: model.extract_entities(
        'Apple CEO Tim Cook announced iPhone 15 in Cupertino yesterday.',
        ['company','person','product','location'], include_spans=True, include_confidence=True))
    result['controls']['relations'] = call('control:relations', lambda: model.extract_relations(
        'Alice works for Acme in Paris.', ['works_for'], include_spans=True, include_confidence=True))
    result['controls']['classification'] = call('control:classification', lambda: model.classify_text(
        'This laptop has amazing performance and excellent battery life!', {'sentiment': ['positive','negative','neutral']}))
    flush()
    options = {k: settings[k] for k in ['threshold','chunk_size','chunk_overlap','batch_size']}
    for doc in documents:
        item = result['documents'].setdefault(doc['id'], {})
        for task in ['entities','relations','classification']:
            if task == 'entities':
                fn = lambda: model.extract_entities_long(doc['text'], config['entities'],
                    include_spans=True, include_confidence=True, **options)
            elif task == 'relations':
                fn = lambda: model.extract_relations_long(doc['text'], config['relations'],
                    include_spans=True, include_confidence=True, **options)
            else:
                fn = lambda: model.classify_text_long(doc['text'], config['classification'],
                    include_spans=False, include_confidence=False, **options)
            before = len(windows)
            answer = call(doc['id']+':'+task, fn)
            verify_coverage(doc['text'],windows[before:])
            item[task] = answer
            save('results/'+doc['id']+'-'+task+'.json', item[task]); flush()
    result['completed'] = True; flush()
    save('worker-result.json', {'status': 'RETURNED_UNEVALUATED', 'model_calls': len(calls),
         'encoder_forwards': len(forwards), 'news_documents': len(documents),
         'evaluation': 'local only; gold was never available to model'})


def clean_env():
    return {'PATH': '/usr/bin:/bin', 'HOME': str(ROOT/'home'), 'HF_HOME': str(ROOT/'home/hf'),
            'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1', 'HF_HUB_DISABLE_IMPLICIT_TOKEN': '1',
            'HF_HUB_DISABLE_TELEMETRY': '1', 'DO_NOT_TRACK': '1', 'TOKENIZERS_PARALLELISM': 'false',
            'OMP_NUM_THREADS': '2', 'MKL_NUM_THREADS': '2', 'OPENBLAS_NUM_THREADS': '2',
            'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1'}


def resource_stop(elapsed, rss):
    if rss > 3*1024**3: return 'RSS_CAP'
    if elapsed > 1200: return 'SEQUENCE_TIMEOUT'
    return None


def supervise():
    import psutil
    verify()
    if (ROOT/'started.json').exists(): raise ValueError('NO_RETRY')
    preflight = {'available_ram_bytes': psutil.virtual_memory().available,
                 'free_disk_bytes': psutil.disk_usage(ROOT).free, 'sample_interval_seconds': 0.10,
                 'rss_cap_bytes': 3*1024**3, 'peak_is_sampled_not_exact': True}
    save('resource-preflight.json', preflight)
    if preflight['available_ram_bytes'] < 3*1024**3 or preflight['free_disk_bytes'] < 2*1024**3:
        save('result.json', {'status': 'HOLD', 'reason': 'RESOURCE_PREFLIGHT', 'model_calls': 0})
        return
    save('started.json', {'epoch': time.time(), 'attempts': 1})
    started = time.monotonic(); peak = 0; reason = None
    with (ROOT/'worker.log').open('w') as log:
        child = subprocess.Popen([sys.executable, '-B', str(ROOT/'run.py'), '--worker'],
            env=clean_env(), stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        process = psutil.Process(child.pid)
        while child.poll() is None:
            try:
                rss = sum(p.memory_info().rss for p in [process]+process.children(recursive=True))
                peak = max(peak, rss); reason = resource_stop(time.monotonic()-started, rss)
            except psutil.NoSuchProcess: pass
            if time.monotonic()-started > 1200: reason = 'SEQUENCE_TIMEOUT'
            if reason:
                os.killpg(child.pid, signal.SIGKILL); child.wait(); break
            time.sleep(0.10)
    result = {'status': 'PARTIAL', 'stop_reason': reason, 'returncode': child.returncode,
              'elapsed_s': time.monotonic()-started, 'sampled_peak_child_tree_RSS_bytes': peak,
              'public_release': False, 'API_expense_USD': 0}
    if (ROOT/'worker-result.json').exists(): result.update(json.loads((ROOT/'worker-result.json').read_bytes()))
    save('result.json', result)


if __name__ == '__main__':
    os.umask(0o077)
    if sys.argv[1:] == ['--worker']: worker()
    elif not sys.argv[1:]: supervise()
    else: raise SystemExit('unsupported mode')
