"""One offline native GLiNER sequence, supervised for time/RSS; never publishes."""
import hashlib
import html
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

from prepare import ROOT, digest, save


def resource_stop(elapsed_s, rss_bytes):
    if rss_bytes > 3*1024**3:
        return "RSS_CAP"
    if elapsed_s > 1200:
        return "SEQUENCE_TIMEOUT"
    return None


def bind(text, value):
    """Accept native exact offsets, otherwise only a unique exact occurrence."""
    if isinstance(value, dict):
        quote = value.get("text")
        start, end = value.get("start"), value.get("end")
        if isinstance(start, int) and isinstance(end, int) and isinstance(quote, str):
            if 0 <= start < end <= len(text) and text[start:end] == quote:
                return {"text": quote, "start": start, "end": end, "method": "native"}
            return None
    else:
        quote = value
    if not isinstance(quote, str) or not quote:
        return None
    start = text.find(quote)
    if start < 0 or text.find(quote, start + 1) >= 0:
        return None
    return {"text": quote, "start": start, "end": start+len(quote), "method": "unique_exact"}


def label(value):
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return value.get("label", value.get("value"))
    return None


def select_main(document, result):
    text = document["text"]
    entities = result.get("entities", {}).get("event_action", [])
    if not isinstance(entities, list):
        entities = [entities]
    mains = [bind(text, e) for e in entities if isinstance(e, dict)
             and label(e.get("relevance")) == "MAIN_NEWS_ACTION"]
    mains = [m for m in mains if m]
    records = result.get("event", [])
    if not isinstance(records, list):
        records = [records]
    selected = []
    for record in records:
        if not isinstance(record, dict):
            continue
        evidence = {key: bind(text, value) for key, value in record.items()}
        action = evidence.get("action")
        if action and any((action["start"],action["end"]) == (m["start"],m["end"]) for m in mains):
            selected.append({"fields": record, "evidence": evidence})
    if len(selected) != 1:
        return {"status": "INSUFFICIENT_EVIDENCE", "reason": "MAIN_EVENT_MISSING_OR_AMBIGUOUS", "candidates": selected}
    item = selected[0]
    if not all(item["evidence"].get(k) for k in ["action","actor","object"]):
        return {"status": "INSUFFICIENT_EVIDENCE", "reason": "MANDATORY_EVIDENCE_UNBOUND", "candidates": selected}
    return {"status": "BOUND", **item}


def packet(documents, selections):
    return [{"id": d["id"], "title": d["title"], "publication_time": d.get("published"),
             "source_url": d["url"], "principal_event": selections[d["id"]]} for d in documents]


def gate(raw, selected):
    values = {k: label(raw.get(k)) for k in ["relation","identity","binding"]}
    if (not raw.get("_meta", {}).get("feasible", False)
            or not all(s.get("status") == "BOUND" for s in selected)
            or values["identity"] == "UNKNOWN" or values["binding"] != "BOUND"):
        return "INSUFFICIENT_EVIDENCE"
    if values["relation"] == "SAME_EVENT" and values["identity"] != "COMPATIBLE_EPISODE":
        return "INSUFFICIENT_EVIDENCE"
    return values["relation"] if values["relation"] in {"SAME_EVENT","DIFFERENT_EVENT"} else "INSUFFICIENT_EVIDENCE"


def verify_pins():
    prepared = json.loads((ROOT / "prepared.json").read_text())
    for path, sha in prepared["files"].items():
        if digest(ROOT / path) != sha:
            raise RuntimeError("FROZEN_INPUT_CHANGED")
    lock = json.loads((ROOT / "lock.json").read_text())
    for spec in lock["model"]:
        if digest(ROOT / "model" / spec["path"]) != spec["sha256"]:
            raise RuntimeError("MODEL_PIN_CHANGED")


def clean_env():
    return {"PATH": "/usr/bin:/bin", "HOME": str(ROOT / "home"),
            "HF_HOME": str(ROOT / "home/hf"), "HF_HUB_OFFLINE": "1",
            "TRANSFORMERS_OFFLINE": "1", "HF_HUB_DISABLE_IMPLICIT_TOKEN": "1",
            "HF_HUB_DISABLE_TELEMETRY": "1", "DO_NOT_TRACK": "1",
            "TOKENIZERS_PARALLELISM": "false", "OMP_NUM_THREADS": "2",
            "MKL_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2",
            "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1"}


def render(result):
    content = html.escape(json.dumps(result, ensure_ascii=False, indent=2))
    documents = []
    if (ROOT / "inputs/documents.json").exists():
        documents = json.loads((ROOT / "inputs/documents.json").read_text())
    blocks = []
    for d in documents:
        blocks.append('<details><summary>'+html.escape(d['title'])+'</summary><p>'+html.escape(d['url'])+'</p><pre>'+html.escape(d['text'])+'</pre></details>')
    page = ('<!doctype html><meta charset="utf-8"><title>BOHUN — Event check trial</title>'
            '<style>body{max-width:1100px;margin:32px auto;font:16px system-ui;padding:16px}pre{white-space:pre-wrap;overflow-wrap:anywhere}details{margin:20px 0}</style>'
            '<h1>Проверка события — частная проба</h1><p>HOLD · public_release=false. Это не опубликованный материал.</p><pre>'+content+'</pre><h2>Сохранённые источники</h2>'+''.join(blocks))
    (ROOT / "review.html").write_text(page)
    (ROOT / "review.html").chmod(0o600)


def preflight_hold(preflight):
    result={"status":"PARTIAL","publication_status":"HOLD","public_release":False,
            "stop_reason":"RESOURCE_PREFLIGHT_HOLD","model_loads":0,"model_calls":0,
            "news_extractions":0,"group_classifications":0,"API_expense_USD":0,
            "quality_result":"NOT_RUN","resource_preflight":preflight}
    save(ROOT / "result.json",result)
    render(result)
    return result


def worker():
    os.umask(0o077)
    def no_network(*args, **kwargs):
        raise RuntimeError("OFFLINE_NETWORK_ATTEMPT")
    socket.socket.connect = no_network
    socket.create_connection = no_network
    socket.getaddrinfo = no_network
    import torch
    torch.set_num_threads(2)
    torch.set_num_interop_threads(2)
    from gliner2 import AutoExtractor
    from gliner2.classification import Classifier, ClassificationSchema, ClassificationConfig
    from gliner2.inference.schema import Schema
    from gliner2.inference.chunking import split_text_into_chunks
    from gliner2.processing.word_splitter import word_splitter_from
    def timed_out(*args):
        raise TimeoutError("HIGH_LEVEL_CALL_TIMEOUT")
    signal.signal(signal.SIGALRM, timed_out)
    calls = []
    forwards = []
    windows = []
    def observation(frame, event, arg):
        if event == "return" and frame.f_code.co_name == "split_text_into_chunks" and isinstance(arg,list):
            windows.append([{"start": c.start_char, "end": c.end_char,
                             "start_word": c.start_word, "end_word": c.end_word} for c in arg])
    sys.setprofile(observation)
    def call(stage, fn):
        if len(calls) >= 26:
            raise RuntimeError("CALL_CAP")
        entry = {"stage": stage, "started": time.time(), "status": "STARTED"}
        calls.append(entry)
        save(ROOT / "progress.json", {"calls":calls,"forwards":forwards,"windows":windows})
        signal.alarm(120)
        try:
            result = fn()
            entry["status"] = "RETURNED"
            return result
        except BaseException as exc:
            entry["status"] = "ERROR"
            entry["error_type"] = type(exc).__name__
            raise
        finally:
            signal.alarm(0)
            entry["elapsed_s"] = time.time() - entry["started"]
            save(ROOT / "progress.json", {"calls":calls,"forwards":forwards,"windows":windows})
    # Model loading is part of the single attempt, bounded separately.
    signal.alarm(120)
    model = AutoExtractor.from_pretrained(str(ROOT / "model"), local_files_only=True).to("cpu").eval()
    signal.alarm(0)
    def count_forward(module, args, kwargs):
        if len(forwards) >= 128:
            raise RuntimeError("FORWARD_CAP")
        tensor = kwargs.get("input_ids", args[0] if args else None)
        shape = list(tensor.shape) if tensor is not None else None
        if shape and shape[-1] > model.config.max_len:
            raise RuntimeError("ENCODED_CONTEXT_TOO_LONG")
        forwards.append({"number":len(forwards)+1,"shape":shape})
    model.encoder.register_forward_pre_hook(count_forward, with_kwargs=True)
    schemas = json.loads((ROOT / "schemas.json").read_text())
    # Native author's example, before any news. Failure ends this one attempt.
    reference_schema = model.create_schema()
    reference_schema.structure("purchase",mode="natural",anchor="buyer").field(
        "buyer",dtype="str",cardinality="required_one").field("item",dtype="str",cardinality="required_one")
    reference = call("reference", lambda: model.extract(schemas["reference_text"],reference_schema))
    save(ROOT / "results/reference.json", reference)
    records = reference.get("purchase",[])
    def textof(value):
        return value.get("text") if isinstance(value,dict) else value
    actual = {(textof(r.get("buyer")),textof(r.get("item"))) for r in records}
    if len(records) != 2 or actual != {("Alice","apples"),("Bob","oranges")}:
        raise RuntimeError("REFERENCE_SEMANTIC_FAILED")
    documents = json.loads((ROOT / "inputs/documents.json").read_text())
    groups = json.loads((ROOT / "inputs/groups.json").read_text())
    schema = Schema()
    # Use the frozen fully-built native schema dictionary, not hand-filled event records.
    extraction_schema = schemas["extract"]
    selections = {}
    for d in documents:
        before_windows = len(windows)
        result = call("extract:"+d["id"], lambda d=d: model.extract_long(
            d["text"],extraction_schema,chunk_size=384,chunk_overlap=64,batch_size=1,
            include_confidence=True,include_spans=True))
        save(ROOT / "results" / (d["id"]+"-extract.json"), result)
        observed = windows[before_windows:]
        if len(observed) != 1:
            raise RuntimeError("CHUNK_OBSERVATION_UNKNOWN")
        covered = set()
        for w in observed[0]:
            covered.update(range(w["start"],w["end"]))
        if any(i not in covered for i,ch in enumerate(d["text"]) if not ch.isspace()):
            raise RuntimeError("DOCUMENT_COVERAGE_GAP")
        selections[d["id"]] = select_main(d,result)
    save(ROOT / "results/selections.json", selections)
    classifier = Classifier(model,device="cpu")
    classification = ClassificationSchema.from_dict(schemas["classify"])
    decisions = []
    by_id = {d["id"]:d for d in documents}
    for group in groups:
        docs = [by_id[i] for i in group["document_ids"]]
        selected = [selections[d["id"]] for d in docs]
        payload = json.dumps(packet(docs,selections),ensure_ascii=False)
        chunks = split_text_into_chunks(payload,chunk_size=model.config.max_len,chunk_overlap=0,
                                       word_splitter=word_splitter_from(model))
        if len(chunks) != 1:
            raw = {}; decision = "INSUFFICIENT_EVIDENCE"; reason="PAIR_CONTEXT_TOO_LONG"
        else:
            answer = call("classify:"+str(group["group"]), lambda: classifier.classify(
                payload,classification,config=ClassificationConfig(batch_size=1,max_len=None)))
            raw = answer.to_dict(); decision=gate(raw,selected); reason=None
        save(ROOT / "results" / (str(group["group"])+"-classify.json"),
             {"input":json.loads(payload),"raw":raw,"decision":decision,"reason":reason})
        decisions.append({**group,"decision":decision,"reason":reason,"raw":raw})
    save(ROOT / "worker-result.json", {"status":"RETURNED_UNEVALUATED",
         "cases":decisions,"calls":len(calls),"forwards":len(forwards),
         "semantic_validation":"evaluation remains local on Mac"})



def supervise():
    import psutil
    verify_pins()
    if (ROOT / "started.json").exists():
        raise RuntimeError("NO_RETRY_ATTEMPT_ALREADY_STARTED")
    available = psutil.virtual_memory().available
    free_disk = psutil.disk_usage(ROOT).free
    preflight={"available_ram_bytes":available,"free_disk_bytes":free_disk,
         "RSS_method":"psutil sum current RSS of child and recursive descendants sampled every 0.10s; sampled, not exact peak",
         "ram_minimum_bytes":3*1024**3,"child_RSS_cap":3*1024**3,"threads":2}
    save(ROOT / "resource-preflight.json",preflight)
    if available < 3*1024**3 or free_disk < 2*1024**3:
        preflight_hold(preflight)
        return
    save(ROOT / "started.json", {"at":time.time(),"status":"SINGLE_ATTEMPT"})
    began=time.monotonic(); peak=0; reason=None
    with (ROOT / "worker.log").open("w") as log:
        child=subprocess.Popen([sys.executable,"-B",str(ROOT / "run.py"),"--worker"],
                               env=clean_env(),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        process=psutil.Process(child.pid)
        while child.poll() is None:
            try:
                rss=sum(p.memory_info().rss for p in [process]+process.children(recursive=True))
                peak=max(peak,rss)
                reason=resource_stop(time.monotonic()-began,rss)
            except psutil.NoSuchProcess:
                pass
            if time.monotonic()-began>1200:reason="SEQUENCE_TIMEOUT"
            if reason:
                os.killpg(child.pid,signal.SIGKILL); child.wait(); break
            time.sleep(0.10)
    result={"status":"PARTIAL","publication_status":"HOLD","public_release":False,
            "returncode":child.returncode,"stop_reason":reason,"elapsed_s":time.monotonic()-began,
            "sampled_peak_child_tree_RSS_bytes":peak,"API_expense_USD":0}
    if (ROOT / "worker-result.json").exists():result.update(json.loads((ROOT / "worker-result.json").read_text()))
    else:result["error_log_tail"]=(ROOT / "worker.log").read_text()[-6000:]
    save(ROOT / "result.json",result);render(result)
    print(json.dumps({k:result[k] for k in ['status','stop_reason','returncode','elapsed_s','sampled_peak_child_tree_RSS_bytes']}))


if __name__ == "__main__":
    os.umask(0o077)
    if sys.argv[1:] == ["--worker"]:
        worker()
    elif not sys.argv[1:]:
        supervise()
    else:
        raise SystemExit("unknown command")
