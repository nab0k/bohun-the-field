"""Versioned local evidence; a valid span is not proof of semantic entailment."""
from contracts import document, extraction, digest, require
import copy


class Ledger:
    def __init__(self, documents, cutoff):
        self.cutoff = cutoff
        self.documents = {}
        for raw in documents:
            item = document(raw, cutoff)
            require(item["id"] not in self.documents, "DOCUMENT_ID_DUPLICATE")
            self.documents[item["id"]] = copy.deepcopy(item)
        self.claims = {}
        self.events = []
        self.revisions = []

    def ingest(self, response):
        claims = extraction(response, self.documents, self.cutoff)
        # Replace the complete version, never silently retain stale evidence.
        self.claims = copy.deepcopy(claims)
        self.events = copy.deepcopy(response["events"])
        self.revisions.append(digest(response))

    def independent_origins(self, refs):
        require(all(ref in self.claims for ref in refs), "UNKNOWN_CLAIM")
        return sorted({self.documents[self.claims[r]["doc_id"]]["root_id"] for r in refs})

    def packet(self):
        return copy.deepcopy({"cutoff": self.cutoff, "documents": list(self.documents.values()),
                "claims": list(self.claims.values()), "events": self.events,
                "semantic_verification": "NOT_RUN"})

    def gaps(self):
        return [{"document_id": d["id"], "reason": "PARTIAL_SOURCE"}
                for d in self.documents.values() if not d["complete"]]
