"""M1 formal comparisons. No market shares, causal coefficients or forecasts."""
from contracts import number, moment, require, Invalid


def compare(a, b, operation="growth"):
    require(operation in {"growth", "difference", "ratio"}, "OPERATION")
    for key in ("subject", "product", "scope", "metric", "stage", "unit", "period_kind"):
        require(a[key] == b[key] and a[key] not in (None, "", "unknown"), "INCOMPATIBLE_" + key.upper())
    if a["unit"] == "money":
        for key in ("currency", "price_basis"):
            require(a[key] == b[key] and a[key] not in (None, "", "unknown"), "INCOMPATIBLE_" + key.upper())
    else:
        require(a["currency"] is b["currency"] is None, "PHYSICAL_CURRENCY")
        require(a["price_basis"] is b["price_basis"] is None, "PHYSICAL_PRICE_BASIS")
    require(a["support"] == b["support"] == "attributed", "UNSUPPORTED")
    require(a["id"] != b["id"] and a["event_id"] != b["event_id"], "SAME_EVENT")
    require(a["stage"] in {"actual", "delivered", "obligated", "contracted"}, "NOT_OBSERVED_CHANGE")
    require(a["period_kind"] in {"year", "quarter", "point"}, "PERIOD_NOT_COMPARABLE")
    for c in (a, b):
        require(c["period_start"] is not None and c["period_end"] is not None, "MISSING_PERIOD")
        start, end = moment(c["period_start"]), moment(c["period_end"])
        if c["period_kind"] == "year":
            require(start.month == 1 and start.day == 1 and end.year == start.year + 1 and end.month == 1 and end.day == 1, "YEAR_BOUNDARY")
        elif c["period_kind"] == "quarter":
            require(start.day == end.day == 1 and start.month in {1, 4, 7, 10}, "QUARTER_BOUNDARY")
            require(end.year * 12 + end.month - (start.year * 12 + start.month) == 3, "QUARTER_LENGTH")
        else:
            require(start == end, "POINT_PERIOD")
    require(moment(a["period_end"]) <= moment(b["period_start"]), "OVERLAPPING_PERIODS")
    require(moment(a["period_start"]) < moment(b["period_start"]), "TIME_DIRECTION")
    before, after = number(a["value"]), number(b["value"])
    if operation in {"ratio", "growth"}:
        require(before > 0, "ZERO_BASELINE")
    value = after - before if operation == "difference" else after / before
    if operation == "growth":
        value = (value - 1) * 100
    return {"operation": operation, "value": str(value), "basis": a["price_basis"] or "physical_quantity",
            "claim_ids": [a["id"], b["id"]], "interpretation": "DESCRIPTIVE_ONLY"}


def scale_context(a, b):
    # Different metric/period is permissible only as a labelled scale comparison.
    require(a["currency"] is not None and a["currency"] == b["currency"], "CURRENCY")
    require(a["unit"] == b["unit"] == "money", "UNIT")
    require(a["support"] == b["support"] == "attributed", "UNSUPPORTED")
    denominator = number(b["value"])
    require(denominator > 0, "ZERO_BASELINE")
    return {"operation": "scale_context", "value": str(number(a["value"]) / denominator * 100),
            "claim_ids": [a["id"], b["id"]], "dates": [a["as_of"], b["as_of"]],
            "metrics": [a["metric"], b["metric"]],
            "interpretation": "CONTEXT_ONLY_NOT_REVENUE_GROWTH_OR_MARKET_SHARE"}


def outcome(fn, *args):
    try:
        return {"status": "ELIGIBLE", "result": fn(*args)}
    except (Invalid, KeyError) as exc:
        return {"status": "BLOCKED", "reason": str(exc)}
