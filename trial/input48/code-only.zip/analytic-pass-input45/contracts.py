"""INPUT45 v0.1: strict local data contracts, not semantic fact verification."""
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import re


class Invalid(ValueError):
    pass


def require(condition, code):
    if not condition:
        raise Invalid(code)


def exact(obj, names):
    require(isinstance(obj, dict) and set(obj) == set(names.split()), "FIELDS")


def nonempty(value):
    require(isinstance(value, str) and bool(value.strip()), "STRING")
    return value


def strings(value, *, empty=False):
    require(isinstance(value, list) and (empty or len(value) > 0), "STRING_LIST")
    for item in value:
        nonempty(item)
    require(len(value) == len(set(value)), "DUPLICATE_REFERENCE")
    return value


def moment(value):
    nonempty(value)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise Invalid("TIME") from None
    require(parsed.tzinfo is not None and parsed.utcoffset() is not None, "TIMEZONE")
    return parsed.astimezone(timezone.utc)


def number(value):
    require(isinstance(value, str), "DECIMAL_STRING")
    try:
        parsed = Decimal(value)
    except InvalidOperation:
        raise Invalid("DECIMAL") from None
    require(parsed.is_finite() and parsed >= 0, "NONNEGATIVE_FINITE")
    return parsed


def quoted_numbers(text):
    """Limited explicit numeric forms. Presence is not event/role entailment."""
    found = set()
    scales = {"million": 1000000, "mln": 1000000, "млн": 1000000,
              "billion": 1000000000, "bn": 1000000000, "млрд": 1000000000,
              "thousand": 1000, "тыс": 1000}
    pattern = r"(?<![\w.])([0-9]+(?:,[0-9]{3})*(?:\.[0-9]+)?)(?![\w.,])\s*(million|mln|billion|bn|thousand|млрд|млн|тыс)?"
    for match in re.finditer(pattern, text, re.IGNORECASE):
        val = Decimal(match[1].replace(",", ""))
        found.add(val * scales.get((match[2] or "").lower(), 1))
    return found


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(encoded(value).encode()).hexdigest()


def text_hash(value):
    return hashlib.sha256(value.encode()).hexdigest()


DOCUMENT_FIELDS = "id url text text_hash root_id published_at received_at complete public_reviewed sensitivity synthetic"


def document(value, cutoff):
    exact(value, DOCUMENT_FIELDS)
    for key in ("id", "url", "text", "root_id"):
        nonempty(value[key])
    require(len(value["text"].encode()) <= 512 * 1024, "SOURCE_SIZE_LIMIT")
    require(value["text_hash"] == text_hash(value["text"]), "TEXT_HASH")
    for key in ("complete", "public_reviewed", "synthetic"):
        require(type(value[key]) is bool, "BOOL")
    require(value["sensitivity"] == "none", "SENSITIVE_SOURCE")
    require(value["synthetic"] or value["public_reviewed"], "PUBLIC_SCOPE_NOT_REVIEWED")
    # Completeness is supplied evidence, never inferred from character count.
    require(moment(value["received_at"]) <= moment(cutoff), "FUTURE_RECEIPT")
    if value["published_at"] is not None:
        require(moment(value["published_at"]) <= moment(cutoff), "FUTURE_PUBLICATION")
    return value


METRICS = {"order", "backlog", "revenue", "capacity", "output", "budget", "fact", "relationship", "opportunity"}
STAGES = {"announced", "target", "authorized", "contracted", "obligated", "delivered", "actual", "unknown"}
CLAIM_FIELDS = "id doc_id event_id subject role product scope metric stage value unit currency period_kind period_start period_end price_basis as_of quote start end support"


def claim(value, docs, cutoff):
    exact(value, CLAIM_FIELDS)
    for key in ("id", "doc_id", "event_id", "subject", "role", "product", "scope"):
        nonempty(value[key])
    require(value["doc_id"] in docs, "CLAIM_DOCUMENT")
    doc = docs[value["doc_id"]]
    require(type(value["start"]) is int and type(value["end"]) is int, "SPAN_TYPE")
    require(0 <= value["start"] < value["end"] <= len(doc["text"]), "SPAN_RANGE")
    require(doc["text"][value["start"]:value["end"]] == nonempty(value["quote"]), "QUOTE_MISMATCH")
    require(value["support"] in {"attributed", "unknown"}, "NO_MODEL_CERTIFICATION")
    require(value["metric"] in METRICS and value["stage"] in STAGES, "CLAIM_ENUM")
    require(value["period_kind"] in {"point", "year", "quarter", "total", "rate", "unknown"}, "PERIOD_KIND")
    require(moment(value["as_of"]) <= moment(cutoff), "FUTURE_OBSERVATION")
    for key in ("unit", "currency", "price_basis"):
        require(value[key] is None or isinstance(value[key], str) and bool(value[key].strip()), "OPTIONAL_STRING")
    start, end = value["period_start"], value["period_end"]
    require((start is None) == (end is None), "PERIOD_PAIR")
    if start is not None:
        require(moment(start) <= moment(end), "PERIOD_ORDER")
        if value["stage"] in {"actual", "delivered"}:
            require(moment(end) <= moment(value["as_of"]), "ACTUAL_PERIOD_IN_FUTURE")
    if value["value"] is not None:
        require(number(value["value"]) in quoted_numbers(value["quote"]), "VALUE_NOT_IN_QUOTE")
        nonempty(value["unit"])
    return value


def extraction(value, docs, cutoff):
    exact(value, "events claims questions")
    require(isinstance(value["claims"], list), "CLAIMS_LIST")
    claims = {}
    for raw in value["claims"]:
        item = claim(raw, docs, cutoff)
        require(item["id"] not in claims, "CLAIM_ID_DUPLICATE")
        claims[item["id"]] = item
    require(isinstance(value["events"], list) and len(value["events"]) > 0, "EVENTS")
    events = {}
    for event in value["events"]:
        exact(event, "id subject product stage claim_ids")
        for key in ("id", "subject", "product"):
            nonempty(event[key])
        require(event["stage"] in STAGES, "EVENT_STAGE")
        strings(event["claim_ids"])
        require(event["id"] not in events, "EVENT_ID_DUPLICATE")
        for ref in event["claim_ids"]:
            require(ref in claims and claims[ref]["event_id"] == event["id"], "EVENT_REFERENCE")
            require(claims[ref]["stage"] == event["stage"], "EVENT_STAGE_CONFLICT")
        events[event["id"]] = event
    require(all(c["event_id"] in events and c["id"] in events[c["event_id"]]["claim_ids"] for c in claims.values()), "ORPHAN_CLAIM")
    require(isinstance(value["questions"], list) and len(value["questions"]) <= 2, "QUESTION_LIMIT")
    for q in value["questions"]:
        exact(q, "question kind public_query source_ids")
        for k in ("question", "kind", "public_query"):
            nonempty(q[k])
        strings(q["source_ids"], empty=True)
    return claims


def draft(value, claims):
    exact(value, "title kind facts inferences unknowns")
    nonempty(value["title"])
    require(value["kind"] in {"news", "signal", "analysis"}, "DRAFT_KIND")
    strings(value["unknowns"], empty=True)
    require(isinstance(value["facts"], list) and len(value["facts"]) > 0, "DRAFT_FACTS")
    require(isinstance(value["inferences"], list), "DRAFT_INFERENCES")
    for row in value["facts"]:
        exact(row, "text claim_ids")
        nonempty(row["text"])
        strings(row["claim_ids"])
        require(all(ref in claims for ref in row["claim_ids"]), "FACT_REFERENCE")
        require(all(claims[ref]["support"] == "attributed" for ref in row["claim_ids"]), "UNKNOWN_FACT_SUPPORT")
    for row in value["inferences"]:
        exact(row, "text method result_id claim_ids assumptions alternative falsifier")
        for key in ("text", "method", "result_id", "alternative", "falsifier"):
            nonempty(row[key])
        strings(row["claim_ids"])
        strings(row["assumptions"], empty=True)
        require(all(ref in claims for ref in row["claim_ids"]), "INFERENCE_REFERENCE")
    return value
