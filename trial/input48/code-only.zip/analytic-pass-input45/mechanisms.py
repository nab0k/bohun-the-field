"""M1/M2/M3: explicit prerequisites. Eligible never means independently true."""
from contracts import exact, strings, nonempty, require, moment, digest, Invalid
from checks import compare, scale_context, outcome


def path(ledger, edges, scope):
    require(isinstance(edges, list) and 0 < len(edges) <= 3, "PATH_LENGTH")
    refs = []
    previous = None
    visited = set()
    for e in edges:
        exact(e, "from to relation scope claim_id valid_from valid_to basis")
        for k in ("from", "to", "relation", "scope"):
            nonempty(e[k])
        require(e["relation"] in {"supplies", "contracted_for", "programme_member"}, "RELATION_NOT_ADMITTED")
        require(e["scope"] == scope and e["basis"] == "documented", "EDGE_SCOPE_OR_BASIS")
        require(e["claim_id"] in ledger.claims, "EDGE_EVIDENCE")
        c = ledger.claims[e["claim_id"]]
        require(c["metric"] == "relationship" and c["support"] == "attributed", "EDGE_CLAIM_TYPE")
        require(c["subject"] == e["from"] and c["scope"] == scope and c["role"] == e["relation"] and e["to"] in c["quote"], "EDGE_BINDING")
        require(moment(e["valid_from"]) <= moment(ledger.cutoff), "EDGE_FUTURE")
        if e["valid_to"] is not None:
            require(moment(e["valid_to"]) >= moment(ledger.cutoff), "EDGE_EXPIRED")
        require(previous is None or e["from"] == previous, "DISCONNECTED_PATH")
        require(e["from"] not in visited and e["to"] not in visited | {e["from"]}, "CYCLE")
        visited.add(e["from"])
        previous = e["to"]
        refs.append(e["claim_id"])
    return {"claim_ids": refs, "scope": scope, "interpretation": "CONDITIONAL_DOCUMENTED_PATH_NOT_SHOCK_ESTIMATE"}


def opportunity(ledger, evidence):
    exact(evidence, "buyer product procedure qualification deadline contact")
    refs = []
    for key, ref in evidence.items():
        require(ref in ledger.claims, "OPPORTUNITY_MISSING_" + key.upper())
        c = ledger.claims[ref]
        require(c["metric"] == "opportunity" and c["role"] == key and c["support"] == "attributed", "OPPORTUNITY_FIELD")
        refs.append(ref)
    cases = {ledger.claims[r]["event_id"] for r in refs}
    require(len(cases) == 1, "OPPORTUNITY_CROSS_EVENT")
    require(len({ledger.claims[r]["product"] for r in refs}) == 1, "OPPORTUNITY_PRODUCT")
    require(all(ledger.claims[r]["scope"] == "public_supplier_call" for r in refs), "OPPORTUNITY_SCOPE")
    # Conservative lexical guard only; semantic classification still needs labels.
    text = ledger.claims[evidence["procedure"]]["quote"].lower()
    require(any(x in text for x in ("supplier", "procurement", "tender", "поставщик", "закуп")), "NO_SUPPLIER_PROCEDURE")
    require(not any(x in text for x in ("lawsuit", "court", "судеб", "исков")), "LEGAL_RFI_NOT_PROCUREMENT")
    deadline = ledger.claims[evidence["deadline"]]
    require(deadline["period_end"] is not None and moment(deadline["period_end"]) > moment(ledger.cutoff), "OPPORTUNITY_EXPIRED_OR_UNKNOWN")
    return {"claim_ids": sorted(set(refs)), "interpretation": "CANDIDATE_ACCESS_REQUIRES_REVIEW"}


def evaluate(ledger, requests):
    require(isinstance(requests, list), "REQUESTS_LIST")
    output = []
    seen = set()
    for r in requests:
        exact(r, "id method args")
        nonempty(r["id"])
        require(r["id"] not in seen, "METHOD_ID_DUPLICATE")
        seen.add(r["id"])
        method, args = r["method"], r["args"]
        try:
            if method in {"M1", "M1_CONTEXT"}:
                exact(args, "before after")
                a, b = ledger.claims[args["before"]], ledger.claims[args["after"]]
                result = outcome(compare if method == "M1" else scale_context, a, b)
            elif method == "M2":
                exact(args, "edges scope")
                result = outcome(path, ledger, args["edges"], args["scope"])
            elif method == "M3":
                result = outcome(opportunity, ledger, args)
            else:
                raise Invalid("METHOD_NOT_ADMITTED")
        except (KeyError, Invalid) as exc:
            result = {"status": "BLOCKED", "reason": str(exc)}
        output.append({"id": r["id"], "method": method, **result})
    return output
