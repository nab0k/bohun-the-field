"""One bounded offline replay. It does not generate or approve analytics."""
import argparse
import json
from pathlib import Path
from contracts import exact, digest, draft, require, Invalid, nonempty, strings, moment
from ledger import Ledger
from mechanisms import evaluate
from ports import ModelPort, ReplayModel, CachedContext, request


def check_inferences(value, results):
    by_id = {r["id"]: r for r in results}
    for row in value["inferences"]:
        require(row["result_id"] in by_id, "UNKNOWN_METHOD_RESULT")
        r = by_id[row["result_id"]]
        require(r["method"] == row["method"] and r["status"] == "ELIGIBLE", "BLOCKED_INFERENCE")
        require(set(r["result"]["claim_ids"]) == set(row["claim_ids"]), "METHOD_EVIDENCE_MISMATCH")
    require(value["kind"] != "analysis" or len(value["inferences"]) > 0, "EMPTY_ANALYSIS")


def run_case(packet, model):
    exact(packet, "id cutoff lead_documents context_documents mechanism_requests baseline")
    nonempty(packet["id"])
    moment(packet["cutoff"])
    require(isinstance(packet["lead_documents"], list) and 0 < len(packet["lead_documents"]) <= 4, "LEAD_LIMIT")
    require(isinstance(packet["context_documents"], list) and len(packet["context_documents"]) <= 4, "CONTEXT_LIMIT")
    exact(packet["baseline"], "status reason")
    require(packet["baseline"]["status"] == "NOT_RUN", "BASELINE_NOT_CONNECTED")
    nonempty(packet["baseline"]["reason"])
    require(isinstance(model, ModelPort), "MODEL_PORT_REQUIRED")
    ledger = Ledger(packet["lead_documents"], packet["cutoff"])
    seed = {"case_id": packet["id"], "cutoff": packet["cutoff"], "documents": list(ledger.documents.values())}
    extracted = model.invoke(request("extract", seed))
    # Phase 2 response may cite context documents requested in phase 1; first
    # validate lead claims without trusting unseen context in the first response.
    ledger.ingest(extracted)
    cache = CachedContext(packet["context_documents"])
    sources, gaps = cache.resolve(extracted["questions"])
    all_docs = list(ledger.documents.values()) + sources
    expanded = Ledger(all_docs, packet["cutoff"])
    expanded.ingest(extracted)
    # Context facts must arrive as separate, quoted claims in the analyze reply.
    analyze_data = {"evidence": expanded.packet(), "context_gaps": gaps,
                    "mechanism_requests": packet["mechanism_requests"]}
    analyzed = model.invoke(request("analyze", analyze_data))
    exact(analyzed, "extraction draft mechanism_requests" if model.plans_mechanisms else "extraction draft")
    mechanism_requests = analyzed["mechanism_requests"] if model.plans_mechanisms else packet["mechanism_requests"]
    expanded.ingest(analyzed["extraction"])
    # No changing the identity/roles/values of lead claims in a later stage.
    for cid, initial in ledger.claims.items():
        require(cid in expanded.claims and expanded.claims[cid] == initial, "LEAD_CLAIM_CHANGED")
    expanded_events = {e["id"]: e for e in expanded.events}
    for initial in ledger.events:
        require(expanded_events.get(initial["id"]) == initial, "LEAD_EVENT_CHANGED")
    results = evaluate(expanded, mechanism_requests)
    proposed = draft(analyzed["draft"], expanded.claims)
    check_inferences(proposed, results)
    subject = {"draft": proposed, "evidence": expanded.packet(), "method_results": results}
    reviewed = model.invoke(request("review", {"review_hash": digest(subject), **subject}))
    exact(reviewed, "review_hash issues")
    require(reviewed["review_hash"] == digest(subject), "REVIEW_VERSION_MISMATCH")
    require(isinstance(reviewed["issues"], list), "ISSUES")
    for issue in reviewed["issues"]:
        exact(issue, "code severity claim_ids detail")
        nonempty(issue["code"])
        nonempty(issue["detail"])
        strings(issue["claim_ids"], empty=True)
        require(issue["severity"] in {"critical", "major", "minor"}, "ISSUE_SEVERITY")
        require(all(ref in expanded.claims for ref in issue["claim_ids"]), "ISSUE_REFERENCE")
    core_supported = any(e["subject"].lower() not in {"unknown", "неизвестно"}
                         and e["product"].lower() not in {"unknown", "неизвестно"}
                         and any(expanded.claims[r]["doc_id"] in ledger.documents for r in e["claim_ids"])
                         for e in expanded.events)
    # An optional unanswered context question must not suppress an otherwise
    # supported news item. Missing evidence for a used inference is blocked above.
    hold = not core_supported or any(i["severity"] in {"critical", "major"} for i in reviewed["issues"])
    audit = model.audit()
    exact(audit, "mode real_model_calls cost_micro_usd calls")
    require(audit["mode"] in {"SYNTHETIC_FIXTURE_REPLAY", "SYNTHETIC", "RECORDED_RESPONSE", "LIVE"}, "MODEL_MODE")
    require(type(audit["real_model_calls"]) is int and 0 <= audit["real_model_calls"] <= 3, "MODEL_CALL_ACCOUNTING")
    require(type(audit["cost_micro_usd"]) is int and audit["cost_micro_usd"] >= 0, "MODEL_COST_ACCOUNTING")
    require(audit["mode"] == "LIVE" or (audit["real_model_calls"] == 0 and audit["cost_micro_usd"] == 0), "FALSE_LIVE_ACCOUNTING")
    body = {"case_id": packet["id"], "mode": audit["mode"], "status": "HOLD" if hold else "EDITOR_CANDIDATE",
            "publication_allowed": False, "semantic_verification": "NOT_RUN", "method_transfer": "NOT_VALIDATED",
            "baseline_A": packet["baseline"], "B": {"evidence": expanded.packet(), "method_results": results},
            "C_fixture" if audit["mode"] == "SYNTHETIC_FIXTURE_REPLAY" else "C_draft": proposed,
            "review": reviewed, "gaps": gaps + expanded.gaps(),
            "origin_count": len(expanded.independent_origins(list(expanded.claims))), "calls": audit["calls"],
            "context_calls": cache.log, "real_model_calls": audit["real_model_calls"], "cost_micro_usd": audit["cost_micro_usd"],
            "quality_AC": {"AC1": "NOT_RUN_HUMAN", "AC3": "NOT_RUN", "AC4": "NOT_RUN", "AC5": "NOT_RUN", "AC6": "NOT_RUN", "AC8": "NOT_RUN"}}
    return {**body, "result_hash": digest(body)}


def execute(bundle):
    exact(bundle, "packet replay")
    try:
        return run_case(bundle["packet"], ReplayModel(bundle["replay"]))
    except Invalid as exc:
        return {"case_id": bundle["packet"].get("id"), "status": "HOLD", "reason": str(exc),
                "publication_allowed": False, "mode": "SYNTHETIC_FIXTURE_REPLAY", "real_model_calls": 0}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("bundle", type=Path)
    args = parser.parse_args()
    # stdout only: caller explicitly chooses where an artifact is saved.
    print(json.dumps(execute(json.loads(args.bundle.read_text())), ensure_ascii=False, indent=2))
