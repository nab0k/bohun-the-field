"""Offline fixture replay only. No transport, keys, retries or provider default."""
import copy
from abc import ABC, abstractmethod
from contracts import exact, digest, require, number


def request(stage, payload):
    require(stage in {"extract", "analyze", "review"}, "MODEL_STAGE")
    return {"stage": stage, "prompt_version": "input45-v0.1", "data": payload}


class ModelPort(ABC):
    """Trusted host-side interface, never loaded from a document or model reply.

    Subclasses implement transport provenance; this is not a remote attestation.
    Semantic quality and publication permission are never granted here.
    """
    plans_mechanisms = False

    @abstractmethod
    def invoke(self, value):
        raise NotImplementedError

    @abstractmethod
    def audit(self):
        raise NotImplementedError


class ReplayModel(ModelPort):
    def __init__(self, entries):
        require(isinstance(entries, list) and len(entries) == 3, "REPLAY_THREE_STAGES")
        self.entries = copy.deepcopy(entries)
        self.log = []

    def invoke(self, value):
        require(len(self.log) < 3, "CALL_LIMIT")
        require(len(self.log) < len(self.entries), "REPLAY_MISSING")
        row = self.entries[len(self.log)]
        exact(row, "stage request_hash response")
        require(row["stage"] == value["stage"] and row["request_hash"] == digest(value), "REPLAY_INPUT_MISMATCH")
        self.log.append({"stage": value["stage"], "request_hash": digest(value),
                         "response_hash": digest(row["response"]), "mode": "SYNTHETIC_FIXTURE",
                         "billed_micro_usd": 0, "real_model_calls": 0})
        return copy.deepcopy(row["response"])

    def audit(self):
        return {"mode": "SYNTHETIC_FIXTURE_REPLAY", "real_model_calls": 0,
                "cost_micro_usd": 0, "calls": copy.deepcopy(self.log)}


class CachedContext:
    def __init__(self, documents):
        self.documents = copy.deepcopy(documents)
        self.log = []

    def resolve(self, questions):
        by_id = {d["id"]: d for d in self.documents}
        require(len(by_id) == len(self.documents), "CONTEXT_DUPLICATE_ID")
        found, gaps = {}, []
        for q in questions:
            refs = q["source_ids"]
            if not refs:
                gaps.append({"question": q["question"], "status": "NOT_SEARCHED"})
            for ref in refs:
                if ref not in by_id:
                    gaps.append({"question": q["question"], "status": "NOT_AVAILABLE", "source_id": ref})
                else:
                    found[ref] = by_id[ref]
            self.log.append({"question": q["question"], "mode": "CACHE_ONLY", "network_calls": 0})
        require(len(found) <= 4, "CONTEXT_LIMIT")
        return list(found.values()), gaps
