"""Identity links use host-reviewed identifiers, never name-only confirmation."""
import re
from urllib.parse import urlsplit
from contracts import exact, nonempty, require, digest


def https_url(value):
    nonempty(value)
    try:
        p = urlsplit(value)
        require(p.scheme == "https" and p.hostname and not p.username and not p.password
                and not any(ord(c) < 33 for c in value), "PUBLIC_SOURCE_URL")
        return value
    except ValueError:
        raise ValueError("PUBLIC_SOURCE_URL") from None


def name_key(value):
    return " ".join(nonempty(value).casefold().split())


def identifier(value):
    exact(value, "kind value")
    require(value["kind"] in {"website", "lei", "uei", "registry", "notion_page_id"}, "IDENTIFIER_KIND")
    v = nonempty(value["value"]).strip()
    if value["kind"] == "website":
        v = urlsplit(https_url(v)).hostname.casefold().removeprefix("www.")
    elif value["kind"] == "notion_page_id":
        v = v.lower().replace("-", "")
        require(bool(re.fullmatch(r"[a-f0-9]{32}", v)), "NOTION_ID")
    else:
        v = v.upper()
        if value["kind"] == "lei": require(bool(re.fullmatch(r"[A-Z0-9]{20}", v)), "LEI_FORMAT")
        if value["kind"] == "uei": require(bool(re.fullmatch(r"[A-Z0-9]{12}", v)), "UEI_FORMAT")
        # Unqualified local registration numbers are not globally unique.
        if value["kind"] == "registry": require(bool(re.fullmatch(r"[A-Z0-9_]+:[A-Z0-9_-]+", v)), "REGISTRY_NAMESPACE")
    return value["kind"], v


def validate_catalog(companies):
    require(isinstance(companies, list) and len(companies) <= 5000, "CATALOG_BOUND")
    seen = set()
    for company in companies:
        exact(company, "id name aliases identifiers identity_status publishable geo")
        nonempty(company["id"]); nonempty(company["name"])
        require(company["id"] not in seen, "COMPANY_ID_DUPLICATE")
        seen.add(company["id"])
        require(company["identity_status"] in {"confirmed", "lead", "unresolved"}, "IDENTITY_STATUS")
        require(type(company["publishable"]) is bool, "COMPANY_PUBLIC_FLAG")
        require(isinstance(company["aliases"], list) and isinstance(company["identifiers"], list), "CATALOG_LIST")
        for alias in company["aliases"]: nonempty(alias)
        for ident in company["identifiers"]:
            exact(ident, "kind value verified source_url")
            identifier({k: ident[k] for k in ("kind", "value")})
            require(type(ident["verified"]) is bool, "IDENTIFIER_VERIFICATION")
            https_url(ident["source_url"])
    return companies


def link_claims(claims, documents, companies, bindings=()):
    validate_catalog(companies)
    docs = {d["id"]: d for d in documents}
    by_claim = {c["id"]: c for c in claims}
    require(len(by_claim) == len(claims), "CLAIM_ID_DUPLICATE")
    direct = {}
    for b in bindings:
        exact(b, "claim_id identifier source_url")
        require(b["claim_id"] in by_claim and b["claim_id"] not in direct, "IDENTITY_BINDING")
        c = by_claim[b["claim_id"]]
        require(b["source_url"] == docs[c["doc_id"]]["url"], "IDENTITY_SOURCE_BINDING")
        https_url(b["source_url"])
        key = identifier(b["identifier"])
        # Stable identity evidence must actually be present in the cited passage.
        literal = key[1]
        haystack = c["quote"].casefold().replace("-", "") if key[0] == "notion_page_id" else c["quote"].casefold()
        require(bool(re.search(r"(?<![\w])" + re.escape(literal.casefold()) + r"(?![\w])", haystack)), "IDENTIFIER_NOT_IN_QUOTE")
        direct[c["id"]] = key
    refs = []
    for c in claims:
        require(c["doc_id"] in docs, "LINK_DOCUMENT")
        candidates, matched = [], []
        for company in companies:
            if name_key(c["subject"]) in {name_key(n) for n in [company["name"], *company["aliases"]]}:
                candidates.append(company["id"])
            if c["id"] in direct and company["identity_status"] == "confirmed" and any(
                    i["verified"] and identifier({k: i[k] for k in ("kind", "value")}) == direct[c["id"]]
                    for i in company["identifiers"]):
                matched.append(company["id"])
        matched, candidates = sorted(set(matched)), sorted(set(candidates) | set(matched))
        status = "matched" if len(matched) == 1 else "ambiguous" if len(matched) > 1 or len(candidates) > 1 else "unresolved"
        refs.append({"link_id": digest([c["id"], c["event_id"], c["subject"], c["role"]]),
                     "company_id": matched[0] if status == "matched" else None,
                     "candidate_ids": candidates, "status": status, "subject": c["subject"],
                     "event_id": c["event_id"], "role": c["role"], "claim_ids": [c["id"]],
                     "source_url": https_url(docs[c["doc_id"]]["url"]),
                     "basis": "reviewed_identifier_and_literal_source" if status == "matched" else "name_candidate_only"})
    return refs
