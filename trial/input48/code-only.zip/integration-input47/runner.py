"""Local bridge. Input files cannot import code, select providers or grant QA."""
import copy
import hashlib
from pathlib import Path
import sys
from contracts import exact, digest, require, encoded
from run import run_case
from company_links import link_claims, validate_catalog, https_url
from geo_projection import company_geography, project_geo


def run_package(package, model):
    exact(package, "packet companies bindings event_geography version")
    require(type(package["version"]) is int and package["version"] > 0, "MATERIAL_VERSION")
    validate_catalog(package["companies"])
    here=Path(__file__).resolve().parent
    paths=[here/n for n in ("model_adapter.py","runner.py","company_links.py","geo_projection.py","preview.py")]
    core=here.parent/"analytic-pass-input45"
    paths += [core/n for n in ("contracts.py","ports.py","ledger.py","checks.py","mechanisms.py","run.py","METHODS.json")]
    code_hashes={str(p.relative_to(here.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    manifest = {"schema": "input47-package-v1", "input_hash": digest(package), "code_hashes":code_hashes,
                "python":sys.version.split()[0],
                "source_hashes": [d["text_hash"] for d in package["packet"]["lead_documents"] +
                                  package["packet"]["context_documents"]], "quality": "NOT_RUN"}
    try:
        result = run_case(copy.deepcopy(package["packet"]), model)
        require(all(hashlib.sha256(p.read_bytes()).hexdigest()==code_hashes[str(p.relative_to(here.parent))] for p in paths), "CODE_CHANGED_DURING_RUN")
        evidence = result["B"]["evidence"]
        refs = link_claims(evidence["claims"], evidence["documents"], package["companies"], package["bindings"])
        geo = company_geography(package["companies"])
        event_ids = {e["id"] for e in evidence["events"]}
        require(isinstance(package["event_geography"], list), "EVENT_GEOGRAPHY")
        seen = set()
        for event in package["event_geography"]:
            exact(event, "event_id geo")
            require(event["event_id"] in event_ids and event["event_id"] not in seen, "GEO_EVENT_BINDING")
            seen.add(event["event_id"])
            geo.append(project_geo("event", event["event_id"], event["geo"], publishable=True))
        draft = result.get("C_draft", result.get("C_fixture"))
        content = {"headline": draft["title"], "kind": draft["kind"],
                   "facts": draft["facts"], "inferences": draft["inferences"], "unknowns": draft["unknowns"],
                   "company_refs": refs, "source_urls": sorted({https_url(d["url"]) for d in evidence["documents"]})}
        material = {"material_id": package["packet"]["id"], "version": package["version"],
                    "content_hash": digest({"content": content, "geography": geo}), **content,
                    "synthetic_sources": any(d["synthetic"] for d in evidence["documents"]),
                    "mode": result["mode"], "status": result["status"], "qa": {"decision": "HOLD", "public_release": False}}
        return {"schema_version": "input47-editor-preview-v1", "manifest": manifest, "result": result,
                "material": material, "companies": copy.deepcopy(package["companies"]), "geography": geo,
                "public_snapshot": public_snapshot(material, package["companies"], geo)}
    except Exception as exc:
        # No source payload, credentials or arbitrary remote exception text in logs.
        return {"schema_version": "input47-editor-preview-v1", "manifest": manifest,
                "result": {"status": "HOLD", "error_type": type(exc).__name__, "publication_allowed": False,
                           "semantic_verification": "NOT_RUN", **model.audit()},
                "material": None, "companies": [], "geography": [], "public_snapshot": empty_snapshot()}


def empty_snapshot():
    return {"schema_version": "bohun-public-materials-v2", "items": [], "companies": [], "geography": []}


def public_snapshot(material, companies, geography, *, release=None):
    """Local proposed projection, not a production signer or publishing endpoint.

    release is a host/editor declaration, NEVER a model field. This function has
    no transport or authority to alter Notion, files on a site or its QA records.
    """
    out = empty_snapshot()
    if release is None:
        return out
    exact(release, "material_id version content_hash projection_hash decision public_release semantic_review")
    content = {k: material[k] for k in ("headline", "kind", "facts", "inferences", "unknowns", "company_refs", "source_urls")}
    if (material["status"] != "EDITOR_CANDIDATE" or material["mode"] not in {"LIVE", "RECORDED_RESPONSE"}
            or material["synthetic_sources"] is not False
            or material["content_hash"] != digest({"content": content, "geography": geography})
            or release["decision"] != "APPROVE" or release["public_release"] is not True
            or release["semantic_review"] != "APPROVE"
            or any(release[k] != material[k] for k in ("material_id", "version", "content_hash"))):
        return out
    allowed = {c["id"] for c in companies if c["publishable"] is True and c["identity_status"] == "confirmed"}
    # Strip candidate identities and every internal catalogue field.
    refs = [{k: r[k] for k in ("company_id", "role", "event_id", "claim_ids", "source_url")}
            for r in material["company_refs"] if r["status"] == "matched" and r["company_id"] in allowed]
    selected = {r["company_id"] for r in refs}
    item = {k: copy.deepcopy(material[k]) for k in ("material_id", "version", "headline", "kind", "facts", "inferences", "unknowns", "source_urls")}
    item["company_refs"] = refs
    public_geo = [copy.deepcopy(g) for g in geography if g["precision"] != "none" and
                  (g["owner_kind"] == "event" or g["owner_id"] in selected)]
    # A private draft's hash cannot be reused after changing its public projection.
    item["reviewed_draft_hash"] = material["content_hash"]
    item["content_hash"] = digest({"item": item, "geography": public_geo})
    item["qa"] = {"decision": "APPROVE", "public_release": True}
    out.update(items=[item], companies=[{"id": c["id"], "name": c["name"]} for c in companies if c["id"] in selected], geography=public_geo)
    # Approval must cover the complete exact public projection, not just a draft.
    if release["projection_hash"] != digest(out):
        return empty_snapshot()
    out["snapshot_hash"] = digest(out)
    return out


if __name__ == "__main__":
    import argparse
    import json
    from model_adapter import AttemptLedger, ModelAdapter, RecordedTransport
    parser=argparse.ArgumentParser(description="Offline recorded-response bridge; no network/model execution")
    parser.add_argument("package",type=Path)
    parser.add_argument("--responses",type=Path,required=True)
    parser.add_argument("--ledger",type=Path,required=True)
    parser.add_argument("--model",required=True)
    parser.add_argument("--html",action="store_true")
    parser.add_argument("--world",type=Path)
    args=parser.parse_args()
    for p in (args.package,args.responses):
        require(p.stat().st_size<=2*1024*1024,"LOCAL_INPUT_BOUND")
    package=json.loads(args.package.read_text())
    entries=json.loads(args.responses.read_text())
    ledger=AttemptLedger(args.ledger,scope="offline-recorded-"+digest(package),cap_micro_usd=0)
    view=run_package(package,ModelAdapter(RecordedTransport(entries),ledger,model=args.model))
    if args.html:
        from preview import render
        world=None
        if args.world:
            require(args.world.stat().st_size<=4*1024*1024,"WORLD_BOUND")
            world=json.loads(args.world.read_text())
        print(render(view,world=world))
    else: print(encoded(view))
