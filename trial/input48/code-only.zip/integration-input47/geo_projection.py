"""Public geography projection. No geocoding, guessed centroids or UA sites."""
import math
import re
from contracts import exact, require, nonempty
from company_links import https_url


def project_geo(owner_kind, owner_id, geo, *, publishable=False):
    require(owner_kind in {"company", "event"}, "GEO_OWNER")
    nonempty(owner_id)
    base = {"owner_kind": owner_kind, "owner_id": owner_id, "precision": "none",
            "country": None, "coordinates": None, "source_url": None, "location_role": None}
    if not publishable or geo is None:
        return {**base, "reason": "NO_PUBLIC_GEOGRAPHY"}
    exact(geo, "country precision coordinates source_url public_reviewed sensitivity location_role")
    require(type(geo["public_reviewed"]) is bool, "GEO_REVIEW_FLAG")
    if not geo["public_reviewed"] or geo["sensitivity"] != "none":
        return {**base, "reason": "GEOGRAPHY_NOT_CLEARED"}
    require(isinstance(geo["country"], str) and re.fullmatch(r"[A-Z]{2}", geo["country"]), "COUNTRY_CODE")
    require(geo["precision"] in {"country", "city", "point"}, "GEO_PRECISION")
    require(geo["location_role"] in {"jurisdiction", "headquarters", "city", "facility", "event"}, "LOCATION_ROLE")
    source = https_url(geo["source_url"])
    # Even reviewed Ukrainian site coordinates are omitted by this first projection.
    if geo["country"] == "UA" or geo["precision"] == "country":
        return {**base, "precision": "country", "country": geo["country"], "source_url": source,
                "location_role": "jurisdiction" if owner_kind == "company" else "event",
                "reason": "COUNTRY_ONLY_NO_COMPANY_POINT"}
    xy = geo["coordinates"]
    require(isinstance(xy, list) and len(xy) == 2 and all(type(n) in {int, float} and math.isfinite(n) for n in xy)
            and -180 <= xy[0] <= 180 and -90 <= xy[1] <= 90, "GEO_COORDINATES")
    require(geo["location_role"] != "jurisdiction", "JURISDICTION_IS_NOT_POINT")
    return {**base, "precision": geo["precision"], "country": geo["country"], "coordinates": list(xy),
            "source_url": source, "location_role": geo["location_role"], "reason": "REVIEWED_PUBLIC_LOCATION"}


def company_geography(companies):
    return [project_geo("company", c["id"], c["geo"],
                        publishable=c["publishable"] and c["identity_status"] == "confirmed") for c in companies]
