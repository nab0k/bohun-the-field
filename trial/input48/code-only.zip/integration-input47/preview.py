"""Self-contained editor HTML. No network assets, hidden fetches or publication."""
from collections import Counter
from html import escape
from contracts import require
from company_links import https_url

# Small display lookup for this local preview; missing codes remain in the list.
# It is not a geocoder or an assertion about company location.
A3 = {"GB": "GBR", "US": "USA", "AT": "AUT", "DE": "DEU", "FR": "FRA", "IL": "ISR",
      "UA": "UKR", "CZ": "CZE", "PL": "POL", "IN": "IND", "CN": "CHN", "MA": "MAR"}
def e(value): return escape(str(value), quote=True)


def geography_svg(geography, world):
    countries = {g["country"] for g in geography if g["precision"] != "none"}
    a2 = {a3: a for a, a3 in A3.items()}
    paths = []
    if world:
        require(world.get("type") == "FeatureCollection" and len(world["features"]) <= 300, "WORLD_BOUND")
        for f in world["features"]:
            geometry = f["geometry"]
            polygons = [geometry["coordinates"]] if geometry["type"] == "Polygon" else geometry["coordinates"] if geometry["type"] == "MultiPolygon" else []
            country = a2.get(f["properties"].get("a3"), "")
            subpaths = []
            for poly in polygons:
                for ring in poly:
                    coords = [(float(x + 180) * 960 / 360, float(90 - y) * 480 / 180) for x, y, *_ in ring]
                    if coords: subpaths.append("M" + "L".join(f"{x:.2f},{y:.2f}" for x, y in coords) + "Z")
            paths.append(f'<path data-country="{e(country)}" class="land {"active" if country in countries else ""}" d="{e(" ".join(subpaths))}"><title>{e(f["properties"].get("name", ""))}</title></path>')
    for g in geography:
        if g["coordinates"] is not None:
            lon, lat = g["coordinates"]
            paths.append(f'<circle data-owner="{e(g["owner_id"])}" cx="{(lon+180)*960/360:.2f}" cy="{(90-lat)*480/180:.2f}" r="3" class="location"><title>{e(g["owner_kind"])} · {e(g["location_role"])}</title></circle>')
    return '<svg id="world" viewBox="0 0 960 480" role="img" aria-label="Разрешённая география компаний и событий">' + ''.join(paths) + '</svg>'


def render(view, *, world=None):
    result, material = view["result"], view["material"]
    mode = result.get("mode", "UNKNOWN")
    synthetic = mode.startswith("SYNTHETIC") or bool(material and material["synthetic_sources"])
    badge = "СИНТЕТИЧЕСКАЯ ПРОВЕРКА · не реальная новость" if synthetic else "РЕДАКТОРСКИЙ ПРОСМОТР · не опубликовано"
    if material is None:
        content = '<article><h1>Материал удержан</h1><p>Проход остановлен. Публикация запрещена.</p></article>'
        refs, companies = [], []
    else:
        refs, companies = material["company_refs"], view["companies"]
        content = f'<article><p class="eyebrow">{e(material["kind"])} · версия {e(material["version"])} · {e(material["status"])}</p><h1>{e(material["headline"])}</h1>'
        for fact in material["facts"]:
            content += f'<p>{e(fact["text"])}</p>'
        for inference in material["inferences"]:
            content += f'<section class="inference"><span class="tag">Метод {e(inference["method"])}</span><p>{e(inference["text"])}</p><details><summary>Основания и ограничения</summary><p>Утверждения: {e(", ".join(inference["claim_ids"]))}</p><p>Допущения: {e("; ".join(inference["assumptions"]))}</p><p>Альтернатива: {e(inference["alternative"])}</p><p>Проверяемое опровержение: {e(inference["falsifier"])}</p></details></section>'
        if material["unknowns"]:
            content += '<h2>Что неизвестно</h2><ul>' + ''.join(f'<li>{e(s)}</li>' for s in material["unknowns"]) + '</ul>'
        content += '<h2>Источники</h2><ol>' + ''.join(f'<li><a href="{e(https_url(s))}" target="_blank" rel="noopener noreferrer">{e(s)}</a></li>' for s in material["source_urls"]) + '</ol>'
        content += f'<p class="muted">Версия связана с хешем {e(material["content_hash"][:16])}. Семантическая проверка: NOT_RUN.</p></article>'
    cards = []
    for c in companies:
        roles = sorted({r["role"] for r in refs if r["company_id"] == c["id"]})
        candidates = any(c["id"] in r["candidate_ids"] for r in refs)
        g = next(g for g in view["geography"] if g["owner_kind"] == "company" and g["owner_id"] == c["id"])
        cards.append(f'<section class="company" data-company="{e(c["id"])}"><h3>{e(c["name"])}</h3><p>{e("; ".join(roles) if roles else "Кандидат по имени" if candidates else "Нет подтверждённой связи с материалом")}</p><p class="muted">{e(g["country"] or "География не установлена")} · {e(g["precision"])}</p><button data-select="{e(c["id"])}">Связи в материале</button></section>')
    rows = ''.join(f'<tr data-ref-company="{e(r["company_id"] or "")}"><td>{e(r["subject"])}</td><td>{e(r["role"])}</td><td>{e(r["status"])}</td><td>{e(", ".join(r["claim_ids"]))}</td></tr>' for r in refs)
    counts = Counter(g["country"] for g in view["geography"] if g["owner_kind"] == "company" and g["precision"] != "none")
    legend = ''.join(f'<button data-country-select="{e(country)}">{e(country)} · компаний {count}</button>' for country, count in sorted(counts.items()))
    return '''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'none'; base-uri 'none'; form-action 'none'">
<title>BOHUN · локальный проход</title><style>
:root{color-scheme:dark;font:16px/1.55 system-ui,sans-serif;background:#101719;color:#e8e8df}*{box-sizing:border-box}body{margin:0}header{border-bottom:1px solid #344143;padding:22px 5vw;display:flex;justify-content:space-between;gap:18px;flex-wrap:wrap}strong,.eyebrow{color:#cdb573}.badge,.tag{font-size:12px;border:1px solid #6b5e37;padding:6px 10px;border-radius:5px}main{max-width:1450px;margin:auto;padding:28px 4vw}.grid{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(250px,1fr);gap:24px}article,.panel{background:#172124;border:1px solid #344143;border-radius:10px;padding:26px;min-width:0}h1{font-size:clamp(25px,3vw,39px);line-height:1.18;font-weight:570;max-width:760px;margin:14px 0 28px}h2{font-size:18px;margin-top:25px}h3{margin:0}.muted,details{color:#b7c2c1;font-size:13px}.eyebrow{font-size:12px;text-transform:uppercase;letter-spacing:.12em}.inference{border-left:2px solid #cdb573;padding:12px 18px;margin:24px 0;background:#202b2c}.company{border-top:1px solid #344143;padding:18px 0}.company.chosen{outline:1px solid #cdb573;padding:12px}button{font:inherit;font-size:13px;background:#202d30;color:#e9dab3;border:1px solid #6b654e;border-radius:5px;padding:7px 11px;cursor:pointer;margin:4px 6px 4px 0}button:focus-visible,a:focus-visible{outline:3px solid #fff}a{color:#d8c28b;overflow-wrap:anywhere}svg{width:100%;background:#10191d;border-radius:6px;max-height:430px}.land{fill:#2e3d40;stroke:#111b1e;stroke-width:.6;fill-rule:evenodd}.land.active{fill:#8b7947}.land.focus{fill:#e0c471}.location{fill:#f3d37a;stroke:#161e1f;stroke-width:.7}.map-panel{margin-top:24px}table{border-collapse:collapse;width:100%;font-size:13px}td,th{text-align:left;border-bottom:1px solid #344143;padding:8px}.table-wrap{overflow:auto}[hidden]{display:none!important}.toolbar{display:flex;flex-wrap:wrap;align-items:center}.notice{margin:16px 0 24px;color:#bcc7c3;font-size:14px}@media(max-width:760px){.grid{grid-template-columns:1fr}article,.panel{padding:20px}main{padding:18px}header{padding:18px}h1{font-size:27px}svg{min-height:210px}}
</style><header><strong>BOHUN / INTELLIGENCE LAB</strong><span class="badge">''' + e(badge) + '''</span></header><main>
<p class="notice">Локальный стенд: материал → компания → география. Аналитическое качество ещё не измерено. Публичных материалов: ''' + str(len(view["public_snapshot"]["items"])) + '''.</p><div class="grid">''' + content + '<aside class="panel"><h2>Компании</h2>' + ''.join(cards) + '''<button id="reset-links">Все связи</button></aside></div><section class="panel map-panel"><div class="toolbar"><h2>География</h2><button id="reset-map">Весь мир</button></div>''' + geography_svg(view["geography"], world) + legend + '''<p class="muted">Заливка — известная страна. Точка — отдельная разрешённая локация; страна не превращается в адрес компании. Это плоский локальный обзор, не глобус сайта. Страны без контура в таблице сопоставления остаются в списке.</p></section><section class="panel map-panel"><h2>Связи и роли</h2><div class="table-wrap"><table><thead><tr><th>Участник</th><th>Роль</th><th>Связь</th><th>Основания</th></tr></thead><tbody>''' + rows + '''</tbody></table></div></section></main><script>
const $s=s=>Array.from(document.querySelectorAll(s));
$s('[data-select]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.select;$s('[data-ref-company]').forEach(r=>r.hidden=r.dataset.refCompany!==id);$s('[data-company]').forEach(c=>c.classList.toggle('chosen',c.dataset.company===id));}));
document.getElementById('reset-links').addEventListener('click',()=>{$s('[data-ref-company]').forEach(r=>r.hidden=false);$s('[data-company]').forEach(c=>c.classList.remove('chosen'));});
const world=document.getElementById('world');
$s('[data-country-select]').forEach(b=>b.addEventListener('click',()=>{const paths=$s('path[data-country]').filter(p=>p.dataset.country===b.dataset.countrySelect);$s('.land').forEach(p=>p.classList.toggle('focus',paths.includes(p)));if(paths.length){const g=paths[0].getBBox();world.setAttribute('viewBox',`${g.x-12} ${g.y-12} ${g.width+24} ${g.height+24}`);}}));
document.getElementById('reset-map').addEventListener('click',()=>{world.setAttribute('viewBox','0 0 960 480');$s('.land').forEach(p=>p.classList.remove('focus'));});
</script></html>'''
