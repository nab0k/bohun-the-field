"""INPUT48 isolated cloud candidate. No network, env reads or execution on import.

Only `cloud --allow-live` may use credentials/network after a separately reviewed
plan. Offline tests inject HTTP. No retries, provider fallback or publication.
"""
import argparse
import base64
import copy
import hashlib
import importlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, ProxyHandler, HTTPRedirectHandler
import zipfile
import zlib

VERSION = 'input48-cloud-v1'
REPO = 'nab0k/bohun-the-field'
ACTOR = 'nab0k'
ACCOUNT = '73a9f47a0d505d1a8cead41487c3f47b'
MODEL = '@cf/qwen/qwen3-30b-a3b-fp8'
TRIAL = 'exp009-input48-first-trial-20261020'
LABEL = 'exp009-input48-live-20261020'
WORKFLOW = '.github/workflows/exp009-input48.yml'
TITLE = f'EXP009 INPUT48 {LABEL} {TRIAL}'
INPUT_HASH = '0875e1a98828c39f5568c59441b225e77f798049dc556c962dc6bb02693faf76'
CASE_IDS = ['CAL01', 'CAL02', 'NEW01', 'NEW02', 'NEW03', 'NEW04']
RESERVE = 3685  # microUSD paid-equivalent of conservative 335 neurons, not invoice
CAP = 1_000_000
LIMIT = 2 * 1024 * 1024
RESULT_LIMIT = 8 * 1024 * 1024
RUNTIME = [f'analytic-pass-input45/{n}' for n in
           ('contracts.py', 'ports.py', 'ledger.py', 'checks.py', 'mechanisms.py', 'run.py', 'METHODS.json')]
RUNTIME += [f'integration-input47/{n}' for n in
            ('model_adapter.py', 'runner.py', 'company_links.py', 'geo_projection.py', 'preview.py')]
BOOTSTRAP = 'CLOUD_TRIAL_INPUT48.py'
ALLOWLIST = set(RUNTIME + [BOOTSTRAP])


class Stop(ValueError):
    pass


def need(condition, code):
    if not condition:
        raise Stop(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def strict_json(raw, limit=LIMIT):
    need(isinstance(raw, bytes) and len(raw) <= limit, 'JSON_BOUND')
    def pairs(items):
        out = {}
        for k, v in items:
            need(k not in out, 'JSON_DUPLICATE_KEY')
            out[k] = v
        return out
    try:
        return json.loads(raw, object_pairs_hook=pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(Stop('NONFINITE_JSON')))
    except Stop:
        raise
    except Exception:
        raise Stop('JSON_INVALID') from None


def private_write(path, raw):
    path = Path(path)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def bundle(source_root, output):
    root = Path(source_root)
    files = {n: (root / n).read_bytes() for n in RUNTIME}
    files[BOOTSTRAP] = Path(__file__).read_bytes()
    manifest = {'version': VERSION, 'files': {n: sha(b) for n, b in files.items()}}
    files['MANIFEST.json'] = encode(manifest)
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for n in sorted(files):
            info = zipfile.ZipInfo(n, (2026, 10, 20, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100600 << 16
            archive.writestr(info, files[n])
    raw = out.getvalue()
    need(len(raw) <= LIMIT, 'BUNDLE_BOUND')
    private_write(output, raw)
    return {'bundle_sha256': sha(raw), 'files': manifest['files'], 'code_files': 13}


def unpack(raw, root, expected):
    need(len(raw) <= LIMIT and sha(raw) == expected, 'BUNDLE_HASH_OR_BOUND')
    root = Path(root)
    need(not root.exists(), 'UNPACK_DESTINATION_EXISTS')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        names = [x.filename for x in entries]
        need(len(names) == len(set(names)) and set(names) == ALLOWLIST | {'MANIFEST.json'}, 'BUNDLE_ALLOWLIST')
        need(sum(x.file_size for x in entries) <= LIMIT, 'BUNDLE_EXPANDED_BOUND')
        for x in entries:
            need(not x.is_dir() and x.file_size <= 524288 and
                 (x.external_attr >> 16) & 0o170000 in (0, 0o100000), 'BUNDLE_ENTRY')
        contents = {n: archive.read(n) for n in names}
    manifest = strict_json(contents['MANIFEST.json'])
    need(set(manifest) == {'version', 'files'} and manifest['version'] == VERSION and
         set(manifest['files']) == ALLOWLIST, 'BUNDLE_MANIFEST')
    need(all(sha(contents[n]) == h for n, h in manifest['files'].items()), 'BUNDLE_CONTENT_HASH')
    root.mkdir(mode=0o700)
    for n, b in contents.items():
        (root / n).parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        private_write(root / n, b)
    verify_tree(root)


def verify_tree(root):
    root = Path(root).resolve()
    manifest = strict_json((root / 'MANIFEST.json').read_bytes())
    need(set(manifest) == {'version', 'files'} and manifest['version'] == VERSION and
         set(manifest['files']) == ALLOWLIST, 'TREE_MANIFEST')
    for n, h in manifest['files'].items():
        p = root / n
        need(p.is_file() and not p.is_symlink() and sha(p.read_bytes()) == h, 'TREE_CHANGED')
    return manifest


def load_runtime(root):
    root = Path(root).resolve()
    verify_tree(root)
    sys.path[:0] = [str(root / 'integration-input47'), str(root / 'analytic-pass-input45')]
    modules = [(Path(n).stem, str(Path(n).parent)) for n in RUNTIME if n.endswith('.py')]
    for name, directory in modules:
        module = importlib.import_module(name)
        need(Path(module.__file__).resolve() == root / directory / (name + '.py'), 'IMPORT_ROOT_COLLISION')
    return importlib.import_module('model_adapter'), importlib.import_module('runner'), importlib.import_module('ports')


def unpack_inputs(b64, expected):
    need(isinstance(b64, str) and len(b64) <= 48000, 'INPUT_ENCODED_BOUND')
    try:
        compressed = base64.b64decode(b64, validate=True)
        decoder = zlib.decompressobj()
        raw = decoder.decompress(compressed, 256 * 1024 + 1)
        need(len(raw) <= 256 * 1024 and decoder.eof and not decoder.unused_data and
             not decoder.unconsumed_tail, 'INPUT_DECOMPRESS_BOUND')
    except Stop:
        raise
    except Exception:
        raise Stop('INPUT_ENCODING') from None
    need(sha(raw) == expected == INPUT_HASH, 'INPUT_HASH')
    value = strict_json(raw)
    need(set(value) == {'version', 'cases'} and value['version'] == 'input48-public-documents-v1', 'INPUT_VERSION')
    need(isinstance(value['cases'], list) and len(value['cases']) == 6, 'CASE_COUNT')
    doc_fields = set('id url text text_hash root_id published_at received_at complete public_reviewed sensitivity synthetic'.split())
    for ident, case in zip(CASE_IDS, value['cases']):
        need(set(case) == {'packet', 'companies', 'bindings', 'event_geography', 'version'} and
             type(case['version']) is int and case['version'] == 1 and not case['companies'] and not case['bindings'] and
             not case['event_geography'], 'PRIVATE_CATALOG_NOT_ALLOWED')
        packet = case['packet']
        need(set(packet) == set('id cutoff lead_documents context_documents mechanism_requests baseline'.split()) and
             packet['id'] == ident, 'CASE_ORDER_OR_FIELDS')
        need(set(packet['baseline']) == {'status', 'reason'} and packet['baseline']['status'] == 'NOT_RUN' and
             packet['mechanism_requests'] == [], 'BASELINE_NOT_INPUT_GOLD')
        need(1 <= len(packet['lead_documents']) <= 4 and len(packet['context_documents']) <= 4, 'DOCUMENT_COUNT')
        seen = set()
        for d in packet['lead_documents'] + packet['context_documents']:
            need(set(d) == doc_fields and d['public_reviewed'] is True and d['synthetic'] is False and
                 d['sensitivity'] == 'none' and type(d['complete']) is bool, 'PUBLIC_DOCUMENT_SCOPE')
            need(d['id'] not in seen and sha(d['text'].encode()) == d['text_hash'], 'DOCUMENT_HASH_OR_ID')
            seen.add(d['id'])
            u = urlsplit(d['url'])
            need(u.scheme == 'https' and u.hostname and not u.username and not u.password, 'SOURCE_URL')
    return value['cases']


def plan_from_event(event):
    """Public PR metadata, written AFTER the head commit. Avoids SHA self-reference."""
    body = event.get('pull_request', {}).get('body')
    start, end = 'BOHUN_INPUT48_APPROVAL_BEGIN\n', '\nBOHUN_INPUT48_APPROVAL_END'
    need(isinstance(body, str) and len(body.encode()) <= 65536 and body.count(start) == 1 and body.count(end) == 1,
         'PR_APPROVAL_BLOCK')
    raw = body.split(start, 1)[1].split(end, 1)[0].encode()
    return strict_json(raw, 16384)


def moment(s):
    try:
        d = datetime.fromisoformat(s.replace('Z', '+00:00'))
        need(d.tzinfo is not None, 'TIME_ZONE')
        return d.astimezone(timezone.utc)
    except Exception:
        raise Stop('TIME_INVALID') from None


def hash_value(x):
    return isinstance(x, str) and re.fullmatch('[a-f0-9]{64}', x) is not None


def validate_plan(plan):
    fields = set(('enabled approval_id trial_id model repo actor pr head_branch head_sha workflow '
                  'label expires_at packet_sha256 bundle_sha256 certificate_sha256 source_hashes '
                  'opening_spent_micro_usd mode free_account_confirmed free_confirmed_at free_confirmation_reference').split())
    need(isinstance(plan, dict) and set(plan) == fields, 'PLAN_FIELDS')
    need(plan['enabled'] is True and isinstance(plan['approval_id'], str) and plan['approval_id'], 'LIVE_NOT_APPROVED')
    need(plan['trial_id'] == TRIAL and plan['model'] == MODEL and plan['repo'] == REPO and
         plan['actor'] == ACTOR and plan['workflow'] == WORKFLOW and plan['label'] == LABEL, 'PLAN_SCOPE')
    need(type(plan['pr']) is int and plan['pr'] > 0 and isinstance(plan['head_branch'], str) and
         re.fullmatch(r'codex/[A-Za-z0-9._/-]+', plan['head_branch']), 'PLAN_PR_BRANCH')
    need(isinstance(plan['head_sha'], str) and re.fullmatch('[a-f0-9]{40}', plan['head_sha']), 'PLAN_HEAD_SHA')
    need(all(hash_value(plan[k]) for k in ['packet_sha256', 'bundle_sha256', 'certificate_sha256']) and
         plan['packet_sha256'] == INPUT_HASH, 'PLAN_HASHES')
    need(isinstance(plan['source_hashes'], list) and bool(plan['source_hashes']) and
         all(hash_value(h) for h in plan['source_hashes']) and
         len(plan['source_hashes']) == len(set(plan['source_hashes'])), 'PLAN_SOURCES')
    now = datetime.now(timezone.utc)
    need(0 < (moment(plan['expires_at']) - now).total_seconds() <= 86400, 'PLAN_EXPIRY')
    opening = plan['opening_spent_micro_usd']
    need(type(opening) is int and 0 <= opening <= CAP - 18 * RESERVE, 'OPENING_BUDGET_UNKNOWN_OR_INSUFFICIENT')
    need(plan['mode'] == 'FREE_ONLY' and plan['free_account_confirmed'] is True and
         isinstance(plan['free_confirmation_reference'], str) and plan['free_confirmation_reference'] and
         0 <= (now - moment(plan['free_confirmed_at'])).total_seconds() <= 86400, 'FREE_ACCOUNT_NOT_CONFIRMED')


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args):
        raise Stop('HTTP_REDIRECT_STOP')


def http(method, url, headers, body=None):
    u = urlsplit(url)
    need(u.scheme == 'https' and u.hostname in {'api.github.com', 'api.cloudflare.com'} and
         not u.username and not u.password and u.port in (None, 443), 'HTTP_DESTINATION')
    need(method == 'GET' or (method == 'POST' and url ==
         f'https://api.cloudflare.com/client/v4/accounts/{ACCOUNT}/ai/run/{MODEL}'), 'HTTP_METHOD_SCOPE')
    request = Request(url, data=body, method=method,
                      headers={'Accept': 'application/json', 'Content-Type': 'application/json',
                               'User-Agent': 'BOHUN-INPUT48/1', **headers})
    try:
        with build_opener(ProxyHandler({}), NoRedirect()).open(request, timeout=45) as reply:
            raw = reply.read(256 * 1024 + 1)
            need(reply.status == 200 and reply.geturl() == url and len(raw) <= 256 * 1024, 'HTTP_REPLY_BOUND')
            return raw
    except Stop:
        raise
    except HTTPError as e:
        raise Stop(f'HTTP_{e.code}_NO_RETRY') from None
    except Exception:
        raise Stop('HTTP_UNKNOWN_NO_RETRY') from None


def cloud_fence(plan, env, event, fetch):
    pr = event.get('pull_request', {})
    need(plan_from_event(event) == plan, 'PR_PLAN_BINDING')
    need(env.get('GITHUB_REPOSITORY') == REPO and env.get('GITHUB_EVENT_NAME') == 'pull_request' and
         env.get('GITHUB_RUN_ATTEMPT') == '1' and env.get('GITHUB_ACTOR') == ACTOR and
         event.get('action') == 'labeled' and event.get('label', {}).get('name') == LABEL and
         event.get('sender', {}).get('login') == ACTOR and event.get('number') == plan['pr'] and
         pr.get('head', {}).get('sha') == plan['head_sha'] and
         pr.get('head', {}).get('ref') == plan['head_branch'] and
         pr.get('head', {}).get('repo', {}).get('full_name') == REPO and
         env.get('GITHUB_REF') == f"refs/pull/{plan['pr']}/merge" and
         env.get('GITHUB_WORKFLOW_REF') == f"{REPO}/{WORKFLOW}@refs/pull/{plan['pr']}/merge", 'CLOUD_CONTEXT')
    run_id = env.get('GITHUB_RUN_ID', '')
    token = env.get('GITHUB_TOKEN')
    need(isinstance(run_id, str) and run_id.isdigit() and isinstance(token, str) and bool(token), 'CLOUD_RUN_ID')
    data = strict_json(fetch('GET', f'https://api.github.com/repos/{REPO}/actions/workflows/exp009-input48.yml/runs?per_page=100',
                             {'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json'}))
    runs = data.get('workflow_runs')
    need(type(data.get('total_count')) is int and 0 < data['total_count'] <= 100 and isinstance(runs, list) and
         len(runs) == data['total_count'], 'HISTORY_UNKNOWN_STOP')
    current = [r for r in runs if str(r.get('id')) == run_id]
    need(len(current) == 1 and current[0].get('display_title') == TITLE and
         current[0].get('head_sha') == plan['head_sha'] and current[0].get('event') == 'pull_request', 'CURRENT_RUN_NOT_PINNED')
    need(not any(str(r.get('id')) != run_id and r.get('display_title') == TITLE for r in runs), 'TRIAL_ALREADY_CONSUMED')
    return {'run_id': run_id, 'head_sha': plan['head_sha'], 'fence': 'ONE_ATTEMPT_NO_RESET'}


def validate_schema(value, schema, depth=0):
    """Closed subset actually used by INPUT47, not a general JSON-Schema engine."""
    need(depth <= 40, 'SCHEMA_DEPTH')
    types = schema.get('type')
    if types is not None:
        types = [types] if isinstance(types, str) else types
        checks = {'object': lambda: isinstance(value, dict), 'array': lambda: isinstance(value, list),
                  'string': lambda: isinstance(value, str), 'integer': lambda: type(value) is int,
                  'null': lambda: value is None}
        need(any(t in checks and checks[t]() for t in types), 'SCHEMA_TYPE')
    if 'enum' in schema:
        need(value in schema['enum'] and not isinstance(value, bool), 'SCHEMA_ENUM')
    if isinstance(value, dict):
        props = schema.get('properties', {})
        need(set(schema.get('required', [])) <= set(value), 'SCHEMA_REQUIRED')
        need(schema.get('additionalProperties') is not False or set(value) <= set(props), 'SCHEMA_EXTRA')
        for k in set(value) & set(props):
            validate_schema(value[k], props[k], depth + 1)
    elif isinstance(value, list):
        need(schema.get('minItems', 0) <= len(value) <= schema.get('maxItems', 10000), 'SCHEMA_ITEMS')
        if schema.get('uniqueItems'):
            need(len({encode(v) for v in value}) == len(value), 'SCHEMA_UNIQUE')
        for v in value:
            validate_schema(v, schema.get('items', {}), depth + 1)
    elif isinstance(value, str):
        need(len(value) >= schema.get('minLength', 0), 'SCHEMA_STRING')
    elif type(value) is int:
        need(value >= schema.get('minimum', value), 'SCHEMA_MINIMUM')


def provider_body(request):
    body = {'messages': [{'role': 'system', 'content': request['instruction'] +
             ' context_index contains the only available context document IDs. Request those exact source_ids when relevant.'},
            {'role': 'user', 'content': encode({'stage': request['stage'], 'data': request['data']}).decode()}],
            'response_format': {'type': 'json_schema', 'json_schema': request['response_schema']},
            'max_tokens': 4096, 'temperature': 0, 'stream': False}
    raw = encode(body)
    need(len(raw) <= 24000, 'HTTP_REQUEST_BOUND_NO_TRUNCATION')
    return raw


def normalize(raw, request):
    envelope = strict_json(raw, 256 * 1024)
    need(envelope.get('success') is True and not envelope.get('errors'), 'CF_ENVELOPE')
    result = envelope.get('result')
    need(isinstance(result, dict), 'CF_RESULT')
    if 'model' in result:
        need(result['model'] == MODEL, 'CF_MODEL_MISMATCH')
    choices = result.get('choices')
    need(isinstance(choices, list) and len(choices) == 1 and choices[0].get('finish_reason') == 'stop', 'CF_INCOMPLETE_CHOICE')
    msg = choices[0].get('message', {})
    need(msg.get('role') == 'assistant' and isinstance(msg.get('content'), str) and
         not msg.get('tool_calls') and not msg.get('refusal'), 'CF_MESSAGE')
    response = strict_json(msg['content'].encode(), 128 * 1024)
    validate_schema(response, request['response_schema'])
    usage = result.get('usage', {})
    it, ot = usage.get('prompt_tokens'), usage.get('completion_tokens')
    need(type(it) is int and 0 <= it <= 24000 and type(ot) is int and 0 <= ot <= 4096, 'CF_USAGE_UNKNOWN')
    if 'total_tokens' in usage:
        need(type(usage['total_tokens']) is int and usage['total_tokens'] == it + ot, 'CF_USAGE_TOTAL')
    # Exact integer ceil of neuron paid-equivalent, NOT verified invoiced money.
    equivalent = (11 * (it * 4625 + ot * 30475) + 999999) // 1000000
    need(equivalent <= RESERVE, 'CF_USAGE_EXCEEDS_RESERVE')
    return {'request_hash': request['request_hash'], 'model': MODEL, 'response': response,
            'usage': {'input_tokens': it, 'output_tokens': ot, 'cost_micro_usd': equivalent}}


def openssl(args, data=None):
    done = subprocess.run(['openssl', *args], input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=45)
    need(done.returncode == 0, 'CRYPTO_FAILED')
    return done.stdout


def test_keys(directory):
    directory = Path(directory)
    directory.mkdir(mode=0o700)
    key, cert = directory / 'test-key.pem', directory / 'test-cert.pem'
    old = os.umask(0o077)
    try:
        openssl(['req', '-x509', '-newkey', 'rsa:3072', '-nodes', '-days', '1',
                 '-subj', '/CN=BOHUN-INPUT48-TEST-ONLY', '-keyout', str(key), '-out', str(cert)])
        key.chmod(0o600); cert.chmod(0o600)
    finally:
        os.umask(old)
    return key, cert


def seal(raw, cert):
    need(len(raw) <= RESULT_LIMIT and b'PRIVATE KEY' not in Path(cert).read_bytes(), 'ENCRYPT_BOUND_OR_CERT')
    return openssl(['cms', '-encrypt', '-binary', '-aes-256-gcm', '-outform', 'DER', str(cert)], raw)


def decrypt(ciphertext, key, cert):
    need(Path(key).stat().st_mode & 0o077 == 0 and len(ciphertext) <= RESULT_LIMIT + 16384, 'DECRYPT_BOUND_OR_MODE')
    return strict_json(openssl(['cms', '-decrypt', '-binary', '-inform', 'DER', '-inkey', str(key),
                               '-recip', str(cert)], ciphertext), RESULT_LIMIT)


def checkpoint(report, ledger_path, cert, output):
    value = copy.deepcopy(report)
    if Path(ledger_path).exists():
        raw = Path(ledger_path).read_bytes()
        need(len(raw) <= LIMIT, 'LEDGER_BOUND')
        value['reservation_ledger'] = [strict_json(line) for line in raw.splitlines()]
    encrypted = seal(encode(value), cert)
    output = Path(output)
    pending = output.with_name(output.name + '.pending')
    private_write(pending, encrypted)
    os.replace(pending, output)


def cloud_run(root, plan, cert, output, env, event, *, bundle_path, fetch=http):
    """No generic credential discovery; only explicit future cloud CLI passes env."""
    validate_plan(plan)
    need(sha(Path(cert).read_bytes()) == plan['certificate_sha256'], 'CERTIFICATE_PIN')
    manifest = verify_tree(root)
    archive_raw = Path(bundle_path).read_bytes()
    need(len(archive_raw) <= LIMIT and sha(archive_raw) == plan['bundle_sha256'], 'EXECUTED_BUNDLE_PIN')
    with zipfile.ZipFile(io.BytesIO(archive_raw)) as archive:
        need(strict_json(archive.read('MANIFEST.json')) == manifest, 'EXECUTED_MANIFEST_PIN')
    seal(b'{}', cert)  # Encryption must work before network or credential use.
    report = {'version': VERSION, 'trial': TRIAL, 'approval_id': plan['approval_id'],
              'status': 'STARTED', 'qa': 'HOLD', 'public_release': False, 'cases': [], 'requests': [],
              'semantic_quality': 'NOT_RUN', 'editor_minutes': None, 'AC6': 'NOT_RUN', 'AC8': 'NOT_RUN',
              'cost_basis': 'PAID_EQUIVALENT_CONSERVATIVE_NOT_INVOICE', 'invoice_micro_usd': None,
              'free_account': 'OWNER_ATTESTED_NOT_API_VERIFIED', 'remaining_neurons': None}
    ledger_path = Path(root) / 'attempts.jsonl'
    need(not ledger_path.exists() and not Path(output).exists(), 'LOCAL_REPLAY_STOP')
    def save():
        checkpoint(report, ledger_path, cert, output)
    save()
    try:
        report['fence'] = cloud_fence(plan, env, event, fetch)
        cases = unpack_inputs(env.get('EXP009_INPUT48_PACKET_B64', ''), plan['packet_sha256'])
        hashes = {d['text_hash'] for c in cases for d in c['packet']['lead_documents'] + c['packet']['context_documents']}
        need(hashes == set(plan['source_hashes']), 'SOURCE_APPROVAL_PIN')
        token = env.get('CF_AI_TOKEN')
        need(isinstance(token, str) and token, 'CF_SECRET_MISSING')
        headers = {'Authorization': 'Bearer ' + token}
        active = strict_json(fetch('GET', 'https://api.cloudflare.com/client/v4/user/tokens/verify', headers))
        need(active.get('success') is True and active.get('result', {}).get('status') == 'active', 'CF_TOKEN_INACTIVE')
        catalog = strict_json(fetch('GET', f'https://api.cloudflare.com/client/v4/accounts/{ACCOUNT}/ai/models/search?per_page=100', headers))
        need(catalog.get('success') is True and isinstance(catalog.get('result'), list) and
             MODEL in {x.get('name') for x in catalog['result']}, 'CF_MODEL_NOT_IN_BOUNDED_CATALOG')
        adapter, runner, ports = load_runtime(root)
        contracts = importlib.import_module('contracts')
        for c in cases:
            for d in c['packet']['lead_documents'] + c['packet']['context_documents']:
                contracts.document(d, c['packet']['cutoff'])
        ledger = adapter.AttemptLedger(ledger_path, scope=TRIAL, cap_micro_usd=CAP, max_attempts=18,
                                      opening_spent_micro_usd=plan['opening_spent_micro_usd'])
        report['access'] = {'token': 'ACTIVE', 'catalog': 'MODEL_PRESENT', 'edit_scope': 'NOT_PROVEN_BEFORE_POST'}
        report['bundle_manifest'] = verify_tree(root)
        save()
        for package in cases:
            ident = package['packet']['id']
            index = [{k: d[k] for k in ('id', 'url', 'published_at')} for d in package['packet']['context_documents']]
            class ContextPort(ports.ModelPort):
                plans_mechanisms = True
                def __init__(self, inner): self.inner = inner
                def invoke(self, value):
                    value = copy.deepcopy(value)
                    if value['stage'] == 'extract':
                        value['data']['context_index'] = index
                        value['data']['host_context_version'] = VERSION
                    return self.inner.invoke(value)
                def audit(self): return self.inner.audit()
            def send(request):
                validate_plan(plan)  # expiry/free attestation never silently rolls over
                verify_tree(root)
                payload = provider_body(request)
                row = {'case': ident, 'stage': request['stage'], 'request_hash': request['request_hash'],
                       'wire_sha256': sha(payload), 'wire_bytes': len(payload), 'outcome': 'DISPATCH_INTENT_UNKNOWN'}
                report['requests'].append(row)
                save()  # ModelAdapter reserved/fsynced BEFORE entering this handler.
                raw = fetch('POST', f'https://api.cloudflare.com/client/v4/accounts/{ACCOUNT}/ai/run/{MODEL}', headers, payload)
                need(isinstance(raw, bytes) and len(raw) <= 256 * 1024, 'PROVIDER_BODY_BOUND')
                row.update(raw_b64=base64.b64encode(raw).decode(), raw_sha256=sha(raw))
                save()  # Preserve original reply even when validation fails.
                reply = normalize(raw, request)
                row.update(outcome='REPLY_CONTRACT_VALID', usage=reply['usage'])
                save()
                return reply
            approval = {'enabled': True, 'approval_id': plan['approval_id'], 'expires_at': plan['expires_at'],
                        'model': MODEL, 'source_hashes': plan['source_hashes']}
            model = ContextPort(adapter.ModelAdapter(adapter.LiveTransport(send, approval=approval), ledger,
                                model=MODEL, maximum_micro_usd=RESERVE))
            view = runner.run_package(package, model)
            report['cases'].append({'case': ident, 'context_index': index, 'context_index_hash': sha(encode(index)), 'view': view})
            save()
            need(view['result'].get('status') == 'EDITOR_CANDIDATE', 'CASE_HOLD_STOP_NO_RETRY')
        report['status'] = 'SIX_CANDIDATES_HUMAN_REVIEW_REQUIRED'
        save()
        return {'status': report['status'], 'artifact': 'ENCRYPTED_ONLY', 'publication': False,
                'attempts': len(report['requests']), 'ciphertext_sha256': sha(Path(output).read_bytes())}
    except Exception as e:
        report['status'] = 'STOPPED_NO_RETRY'
        report['reason'] = str(e) if isinstance(e, Stop) and re.fullmatch('[A-Z0-9_]+', str(e)) else 'BOUNDARY_ERROR'
        save()  # Failure here remains UNKNOWN; never re-run to recover a receipt.
        raise Stop('CLOUD_STOP_SEE_ENCRYPTED_RECEIPT') from None


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    b = sub.add_parser('bundle'); b.add_argument('--source-root', required=True); b.add_argument('--output', required=True)
    u = sub.add_parser('unpack')
    for n in ('bundle', 'root', 'sha256'): u.add_argument('--' + n, required=True)
    c = sub.add_parser('cloud')
    for n in ('root', 'bundle', 'plan', 'certificate', 'output'): c.add_argument('--' + n, required=True)
    c.add_argument('--allow-live', action='store_true')
    d = sub.add_parser('decrypt')
    for n in ('ciphertext', 'key', 'certificate', 'output'): d.add_argument('--' + n, required=True)
    args = p.parse_args()
    try:
        if args.command == 'bundle':
            result = bundle(args.source_root, args.output)
        elif args.command == 'unpack':
            unpack(Path(args.bundle).read_bytes(), args.root, args.sha256); result = {'unpacked': True}
        elif args.command == 'decrypt':
            value = decrypt(Path(args.ciphertext).read_bytes(), args.key, args.certificate)
            private_write(args.output, encode(value)); result = {'decrypted': True, 'publication': False}
        else:
            need(args.allow_live, 'LIVE_FLAG_REQUIRED')
            plan = strict_json(Path(args.plan).read_bytes())
            validate_plan(plan)  # no env/token access before plan approval
            event = strict_json(Path(os.environ['GITHUB_EVENT_PATH']).read_bytes())
            result = cloud_run(args.root, plan, args.certificate, args.output, os.environ, event, bundle_path=args.bundle)
        print(encode(result).decode())
        return 0
    except Exception:
        print('{"status":"STOPPED_NO_RETRY","details":"PRIVATE_OR_ENCRYPTED_RECEIPT"}')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
